package com.just.ai.goap.sensor;

import com.just.ai.goap.StateKey;
import com.just.ai.goap.state.ReadableWorldState;
import java.util.Set;

/**
 * A {@link Sensor.Multi} whose values are held for a fixed number of ticks. Created by {@link Sensors#every}.
 * <p>
 * Added in 0.4.1. See {@link RefreshingMono}.
 * </p>
 */
final class RefreshingMulti<T> implements Sensor.Multi<T> {
   private final int refreshTicks;
   private final Sensor.Multi<T> delegate;

   RefreshingMulti(int refreshTicks, Sensor.Multi<T> delegate) {
      this.refreshTicks = refreshTicks;
      this.delegate = delegate;
   }

   @Override
   public Set<StateKey.Sensed<?>> outputKeys() {
      return this.delegate.outputKeys();
   }

   @Override
   public <V> V apply(StateKey<V> key, T actor, ReadableWorldState worldState) {
      return this.delegate.apply(key, actor, worldState);
   }

   @Override
   public int refreshTicks() {
      return this.refreshTicks;
   }

   @Override
   public String toString() {
      return "every(" + this.refreshTicks + ", " + this.delegate + ")";
   }
}
