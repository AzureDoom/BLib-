package com.just.ai.goap;

import java.util.Objects;
import org.jetbrains.annotations.NotNull;

public abstract sealed class StateKey<T> permits StateKey.Derived, StateKey.Sensed {
   private static final int UNSET = Integer.MIN_VALUE;
   protected final String id;
   private transient int cachedHashCode = Integer.MIN_VALUE;

   public static <T> StateKey.Derived<T> derived(String id) {
      return new StateKey.Derived<>(id);
   }

   public static <T> StateKey.Sensed<T> sensed(String id) {
      return new StateKey.Sensed<>(id);
   }

   protected StateKey(String id) {
      this.id = id;
   }

   public abstract StateKey.Derived<T> asDerived();

   public abstract StateKey.Sensed<T> asSensed();

   public String id() {
      return this.id;
   }

   @Override
   public boolean equals(Object o) {
      return o instanceof StateKey<?> key ? Objects.equals(this.id, key.id) : false;
   }

   @Override
   public int hashCode() {
      int hashCode = this.cachedHashCode;
      if (hashCode == Integer.MIN_VALUE) {
         hashCode = this.id.hashCode();
         this.cachedHashCode = hashCode;
      }

      return hashCode;
   }

   public static final class Derived<T> extends StateKey<T> {
      private Derived(String id) {
         super(id);
      }

      @Override
      public StateKey.Derived<T> asDerived() {
         return this;
      }

      @Override
      public StateKey.Sensed<T> asSensed() {
         return new StateKey.Sensed<>(this.id);
      }

      @NotNull
      @Override
      public String toString() {
         return "derived:" + this.id;
      }
   }

   public static final class Sensed<T> extends StateKey<T> {
      private Sensed(String id) {
         super(id);
      }

      @Override
      public StateKey.Derived<T> asDerived() {
         return new StateKey.Derived<>(this.id);
      }

      @Override
      public StateKey.Sensed<T> asSensed() {
         return this;
      }

      @NotNull
      @Override
      public String toString() {
         return "sensed:" + this.id;
      }
   }
}
