package com.just.ai.goap.graph;

import com.just.ai.goap.StateKey;
import com.just.ai.goap.action.Action;
import com.just.ai.goap.condition.Condition;
import com.just.ai.goap.goal.Goal;
import com.just.ai.goap.sensor.Sensor;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class GraphValidator {
   private static final Logger LOGGER = LoggerFactory.getLogger(GraphValidator.class);

   static <T> void validate(
      Set<Action<? super T>> availableActions,
      Set<Goal> availableGoals,
      Map<Condition<?>, Set<Action<? super T>>> preconditionToSatisfyingActionsMap,
      Map<StateKey<?>, Sensor<? super T>> sensorMap
   ) {
      GraphValidator.ValidationErrorCollector validationErrorCollector = new GraphValidator.ValidationErrorCollector();
      validateGoalPreconditionSatisfiabilityOrThrow(validationErrorCollector, availableGoals, sensorMap);
      validateKeySatisfiabilityOrThrow(validationErrorCollector, availableActions, sensorMap);
      validateGoalReachabilityOrThrow(validationErrorCollector, availableGoals, preconditionToSatisfyingActionsMap);
      validateActionContributionOrThrow(validationErrorCollector, availableActions, availableGoals);
      validationErrorCollector.flushAndThrowIfAny();
   }

   private static <T> void validateGoalPreconditionSatisfiabilityOrThrow(
      GraphValidator.ValidationErrorCollector validationErrorCollector, Set<Goal> availableGoals, Map<StateKey<?>, Sensor<? super T>> sensorMap
   ) {
      for (Goal goal : availableGoals) {
         for (Condition<?> condition : goal.getPreconditions().getConditions()) {
            StateKey<?> sensedKey = condition.key();
            if (!sensorMap.containsKey(sensedKey)) {
               String quotedSensedKey = "'" + sensedKey + "'";
               String errorMessage = quotedSensedKey
                  + " is a precondition in '"
                  + goal
                  + "' but "
                  + quotedSensedKey
                  + " has no sensor. Consider adding a sensor that senses "
                  + quotedSensedKey
                  + ".";
               validationErrorCollector.error(errorMessage);
            }
         }
      }
   }

   private static <T> void validateKeySatisfiabilityOrThrow(
      GraphValidator.ValidationErrorCollector validationErrorCollector, Set<Action<? super T>> availableActions, Map<StateKey<?>, Sensor<? super T>> sensorMap
   ) {
      HashMap<StateKey.Derived<?>, Set<Action<? super T>>> derivedKeyProducerMap = new HashMap<>();

      for (Action<? super T> action : availableActions) {
         action.getEffectContainer().getEffects().forEach(effect -> derivedKeyProducerMap.computeIfAbsent(effect.key(), $ -> new HashSet<>()).add(action));
      }

      for (Action<? super T> action : availableActions) {
         for (Condition<?> precondition : action.getPreconditionContainer().getConditions()) {
            StateKey<?> key = precondition.key();
            switch (key) {
               case StateKey.Derived var27:
                  StateKey.Derived<?> derivedKey = (StateKey.Derived<?>)key;
                  Set<Action<? super T>> keyProducers = derivedKeyProducerMap.getOrDefault(derivedKey, Set.of());
                  boolean onlySelfProduces = keyProducers.size() == 1 && keyProducers.contains(action);
                  boolean noProducers = keyProducers.isEmpty();
                  boolean noSensorx = !sensorMap.containsKey(derivedKey);
                  if ((onlySelfProduces || noProducers) && noSensorx) {
                     String quotedPrecondition = "'" + precondition + "'";
                     String quotedAction = "'" + action + "'";
                     String errorMessage = String.format(
                        "Action %s has a precondition %s with no possible action that can satisfy %s. Possible fixes:\n    - Add an action that can satisfy the precondition %s\n    - Remove the precondition %s from %s",
                        quotedAction,
                        quotedPrecondition,
                        quotedPrecondition,
                        quotedPrecondition,
                        quotedPrecondition,
                        quotedAction
                     );
                     validationErrorCollector.error(errorMessage);
                  }
                  break;
               case StateKey.Sensed<?> sensedKey:
                  boolean noSensor = !sensorMap.containsKey(sensedKey);
                  if (noSensor) {
                     String quotedPrecondition = "'" + precondition + "'";
                     String quotedPreconditionKey = "'" + precondition.key().id() + "'";
                     String quotedAction = "'" + action + "'";
                     String errorMessage = String.format(
                        "Action %s has a precondition %s with no possible sensor that can sense %s. Possible fixes:\n    - Add a sensor that senses %s\n    - Remove the precondition %s from %s",
                        quotedAction,
                        quotedPrecondition,
                        quotedPreconditionKey,
                        quotedPreconditionKey,
                        quotedPrecondition,
                        quotedAction
                     );
                     validationErrorCollector.error(errorMessage);
                  }
                  break;
               default:
                  throw new MatchException(null, null);
            }
         }
      }
   }

   private static <T> void validateGoalReachabilityOrThrow(
      GraphValidator.ValidationErrorCollector validationErrorCollector,
      Set<Goal> availableGoals,
      Map<Condition<?>, Set<Action<? super T>>> preconditionToSatisfyingActionsMap
   ) {
      for (Goal goal : availableGoals) {
         for (Condition<?> desiredCondition : goal.getDesiredConditions().getConditions()) {
            Set<Action<? super T>> satisfyingActions = preconditionToSatisfyingActionsMap.getOrDefault(desiredCondition, Set.of());
            if (satisfyingActions.isEmpty()) {
               String quotedGoal = "'" + goal + "'";
               String quotedPrecondition = "'" + desiredCondition + "'";
               String errorMessage = String.format(
                  "Goal %s has a desired condition %s with no possible action that can satisfy it. Possible fixes:\n    - Add an action that can satisfy the desired precondition %s\n    - Remove the desired precondition %s from %s",
                  quotedGoal,
                  quotedPrecondition,
                  quotedPrecondition,
                  quotedPrecondition,
                  quotedGoal
               );
               validationErrorCollector.error(errorMessage);
            }
         }
      }
   }

   private static <T> void validateActionContributionOrThrow(
      GraphValidator.ValidationErrorCollector validationErrorCollector, Set<Action<? super T>> availableActions, Set<Goal> availableGoals
   ) {
      HashSet<Condition<?>> usefulConditions = new HashSet<>();
      HashSet<Action<? super T>> reachableActions = new HashSet<>();

      for (Goal goal : availableGoals) {
         usefulConditions.addAll(goal.getDesiredConditions().getConditions());
      }

      boolean changed;
      do {
         changed = false;

         for (Action<? super T> action : availableActions) {
            if (!reachableActions.contains(action)) {
               boolean useful = usefulConditions.stream().anyMatch(condition -> condition.satisfiedBy(action.getEffectContainer()));
               if (useful) {
                  reachableActions.add(action);

                  for (Condition<?> pre : action.getPreconditionContainer().getConditions()) {
                     if (usefulConditions.add(pre)) {
                        changed = true;
                     }
                  }

                  changed = true;
               }
            }
         }
      } while (changed);

      for (Action<? super T> actionx : availableActions) {
         if (!reachableActions.contains(actionx)) {
            String quotedAction = "'" + actionx + "'";
            String errorMessage = String.format(
               "Action %s is a dead end and doesn't satisfy any other action or goal. Possible fixes:\n    - Change the effects of %s such that one of the effects satisfies an action or goal precondition\n    - Change the desired conditions of one of your goals to match the effects of %s\n    - Remove %s",
               quotedAction,
               quotedAction,
               quotedAction,
               quotedAction
            );
            validationErrorCollector.error(errorMessage);
         }
      }
   }

   private GraphValidator() {
      throw new UnsupportedOperationException();
   }

   static class ValidationErrorCollector {
      private final Set<String> errors = new LinkedHashSet<>();

      void error(String message) {
         this.errors.add(message);
      }

      void flushAndThrowIfAny() {
         if (!this.errors.isEmpty()) {
            GraphValidator.LOGGER.error("GOAP graph validation failed with the following errors:");

            for (String error : this.errors) {
               GraphValidator.LOGGER.error("- {}", error);
            }

            System.err.println("GOAP graph validation failed with the following errors:");

            for (String error : this.errors) {
               System.err.println("- " + error);
            }

            throw new IllegalStateException("GOAP graph validation failed.");
         }
      }
   }
}
