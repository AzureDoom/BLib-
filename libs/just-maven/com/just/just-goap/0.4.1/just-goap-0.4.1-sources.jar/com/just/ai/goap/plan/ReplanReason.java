package com.just.ai.goap.plan;

public enum ReplanReason {
   ACTIVE_PLANS_PRESENT,
   ALL_POLICIES_MATCHED,
   ALL_POLICY_BLOCKED,
   ALWAYS,
   ANY_POLICY_MATCHED,
   ANY_POLICIES_BLOCKED,
   CUSTOM_POLICY,
   NEVER,
   NO_ACTIVE_PLANS;
}
