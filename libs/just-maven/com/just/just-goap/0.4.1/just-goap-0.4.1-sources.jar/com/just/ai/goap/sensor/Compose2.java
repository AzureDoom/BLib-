package com.just.ai.goap.sensor;

import com.just.ai.goap.StateKey;
import com.just.ai.goap.state.ReadableWorldState;
import com.just.core.functional.function.Function3;

public final class Compose2<T, I1, I2, O1> implements Sensor.Mono<T, O1> {
   private final StateKey.Sensed<I1> sourceKeyA;
   private final StateKey.Sensed<I2> sourceKeyB;
   private final StateKey.Sensed<O1> outputKeyA;
   private final Function3<? super T, ? super I1, ? super I2, ? extends O1> extractor;

   Compose2(
      StateKey.Sensed<I1> sourceKeyA,
      StateKey.Sensed<I2> sourceKeyB,
      StateKey.Sensed<O1> outputKeyA,
      Function3<? super T, ? super I1, ? super I2, ? extends O1> extractor
   ) {
      this.sourceKeyA = sourceKeyA;
      this.sourceKeyB = sourceKeyB;
      this.outputKeyA = outputKeyA;
      this.extractor = extractor;
   }

   @Override
   public StateKey.Sensed<O1> key() {
      return this.outputKeyA;
   }

   @Override
   public <V> V apply(StateKey<V> key, T actor, ReadableWorldState worldState) {
      I1 sourceValueA = worldState.getOrNull(this.sourceKeyA);
      I2 sourceValueB = worldState.getOrNull(this.sourceKeyB);
      return (V)this.extractor.apply(actor, sourceValueA, sourceValueB);
   }
}
