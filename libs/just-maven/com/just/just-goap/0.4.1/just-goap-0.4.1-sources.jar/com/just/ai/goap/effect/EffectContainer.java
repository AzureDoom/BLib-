package com.just.ai.goap.effect;

import com.just.ai.goap.state.ReadableWorldState;
import com.just.ai.goap.state.WorldState;
import com.just.core.functional.function.Lazy;
import java.util.List;

public final class EffectContainer {
   private final List<Effect<?>> effects;
   private final Lazy<WorldState> worldStateLazy;

   public static EffectContainer of(Effect<?>... effects) {
      return of(List.of(effects));
   }

   public static EffectContainer of(List<Effect<?>> effects) {
      return new EffectContainer(effects);
   }

   private EffectContainer(List<Effect<?>> effects) {
      this.effects = effects;
      this.worldStateLazy = Lazy.of(() -> {
         WorldState worldState = WorldState.create();
         worldState.apply(this);
         return worldState;
      });
   }

   public List<Effect<?>> getEffects() {
      return this.effects;
   }

   public ReadableWorldState toWorldState() {
      return (ReadableWorldState)this.worldStateLazy.get();
   }
}
