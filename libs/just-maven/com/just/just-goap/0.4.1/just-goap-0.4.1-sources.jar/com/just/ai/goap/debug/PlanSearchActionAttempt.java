package com.just.ai.goap.debug;

import java.util.List;

public record PlanSearchActionAttempt(String actionName, List<String> resultingUnsatisfiedConditions, float actionCost, float heuristicCost) {
   public PlanSearchActionAttempt(String actionName, List<String> resultingUnsatisfiedConditions, float actionCost, float heuristicCost) {
      resultingUnsatisfiedConditions = List.copyOf(resultingUnsatisfiedConditions);
      this.actionName = actionName;
      this.resultingUnsatisfiedConditions = resultingUnsatisfiedConditions;
      this.actionCost = actionCost;
      this.heuristicCost = heuristicCost;
   }
}
