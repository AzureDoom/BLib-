package com.just.ai.goap.debug;

import java.util.List;

public record PlanSearchResult(
   long tick,
   String goalName,
   boolean goalPreconditionsSatisfied,
   boolean desiredConditionsSatisfied,
   List<String> rootUnsatisfiedConditions,
   PlanSearchStatus status,
   List<String> selectedActions,
   float cost,
   boolean truncated,
   List<PlanSearchStep> steps
) {
   public PlanSearchResult(
      long tick,
      String goalName,
      boolean goalPreconditionsSatisfied,
      boolean desiredConditionsSatisfied,
      List<String> rootUnsatisfiedConditions,
      PlanSearchStatus status,
      List<String> selectedActions,
      float cost,
      boolean truncated,
      List<PlanSearchStep> steps
   ) {
      rootUnsatisfiedConditions = List.copyOf(rootUnsatisfiedConditions);
      selectedActions = List.copyOf(selectedActions);
      steps = List.copyOf(steps);
      this.tick = tick;
      this.goalName = goalName;
      this.goalPreconditionsSatisfied = goalPreconditionsSatisfied;
      this.desiredConditionsSatisfied = desiredConditionsSatisfied;
      this.rootUnsatisfiedConditions = rootUnsatisfiedConditions;
      this.status = status;
      this.selectedActions = selectedActions;
      this.cost = cost;
      this.truncated = truncated;
      this.steps = steps;
   }
}
