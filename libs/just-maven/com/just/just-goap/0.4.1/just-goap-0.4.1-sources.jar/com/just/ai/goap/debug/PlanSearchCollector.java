package com.just.ai.goap.debug;

import com.just.ai.goap.AOStar;
import com.just.ai.goap.action.Action;
import com.just.ai.goap.condition.Condition;
import com.just.ai.goap.condition.ConditionContainer;
import java.util.List;

public interface PlanSearchCollector {
   void started(ConditionContainer var1);

   void expanded(Condition<?> var1, List<? extends Action<?>> var2);

   void triedAction(Action<?> var1, ConditionContainer var2, float var3, float var4);

   void solved(List<? extends AOStar.ActionWithCost<?>> var1);

   void failed();
}
