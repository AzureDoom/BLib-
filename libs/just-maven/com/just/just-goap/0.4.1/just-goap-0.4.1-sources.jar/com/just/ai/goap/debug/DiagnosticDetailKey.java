package com.just.ai.goap.debug;

import java.util.Objects;

public record DiagnosticDetailKey<T>(String id, Class<T> type) {
   public DiagnosticDetailKey(String id, Class<T> type) {
      if (id != null && !id.isBlank()) {
         type = Objects.requireNonNull(type, "type");
         this.id = id;
         this.type = type;
      } else {
         throw new IllegalArgumentException("id must not be blank");
      }
   }

   public static <T> DiagnosticDetailKey<T> of(String id, Class<T> type) {
      return new DiagnosticDetailKey<>(id, type);
   }

   public DiagnosticDetail<T> detail(T value) {
      return new DiagnosticDetail<>(this, value);
   }
}
