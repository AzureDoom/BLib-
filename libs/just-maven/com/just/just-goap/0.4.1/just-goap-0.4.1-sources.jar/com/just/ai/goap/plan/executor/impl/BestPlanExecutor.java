package com.just.ai.goap.plan.executor.impl;

import com.just.ai.goap.Agent;
import com.just.ai.goap.debug.AgentDiagnostics;
import com.just.ai.goap.debug.DiagnosticDetailKeys;
import com.just.ai.goap.debug.DiagnosticEventKind;
import com.just.ai.goap.debug.DiagnosticReason;
import com.just.ai.goap.plan.Plan;
import com.just.ai.goap.plan.executor.PlanExecutor;
import com.just.ai.goap.plan.scorer.PlanScorer;
import com.just.ai.goap.plan.scorer.PlanScorers;
import com.just.ai.goap.state.ReadableWorldState;
import java.util.List;
import org.jetbrains.annotations.Nullable;

public class BestPlanExecutor<T> implements PlanExecutor<T> {
   private final PlanScorer<T> planScorer;
   @Nullable
   private Plan<T> currentPlan;

   public BestPlanExecutor() {
      this(PlanScorers.costEfficiency());
   }

   public BestPlanExecutor(PlanScorer<T> planScorer) {
      this.planScorer = planScorer;
      this.currentPlan = null;
   }

   @Override
   public PlanExecutor.Result execute(PlanExecutor.ExecutionContext<T> context) {
      if (this.currentPlan == null) {
         return PlanExecutor.Result.NO_PLANS;
      } else {
         Agent.Debugger timings = context.agent().getDebug().getTimings();
         timings.push("BestPlanExecutor.execute()");
         Plan.State planState = this.currentPlan.update(context.agent(), context.actor(), context.currentWorldState(), context.previousWorldState());
         timings.pop();

         return switch (planState) {
            case ABORTED, FINISHED, INVALID -> {
               AgentDiagnostics diagnostics = context.agent().getDebug().getDiagnostics();
               if (diagnostics.isEnabled()) {
                  diagnostics.recordPlanEvent(
                     context.agent().getTick(),
                     DiagnosticEventKind.PLAN_REMOVED,
                     this.currentPlan,
                     AgentDiagnostics.details(DiagnosticDetailKeys.PLAN_STATE.detail(planState))
                  );
               }

               this.currentPlan = null;
               yield PlanExecutor.Result.IDLE;
            }
            case IN_PROGRESS -> PlanExecutor.Result.IN_PROGRESS;
         };
      }
   }

   @Override
   public void supplyPlans(List<Plan<T>> plans, T actor, ReadableWorldState worldState) {
      if (!plans.isEmpty() && this.currentPlan == null) {
         this.currentPlan = this.selectBestPlan(plans, actor, worldState);
      }
   }

   @Override
   public void supplyPlans(PlanExecutor.SupplyContext<T> context) {
      if (!context.plans().isEmpty()) {
         AgentDiagnostics diagnostics = context.agent().getDebug().getDiagnostics();
         boolean diagnosticsEnabled = diagnostics.isEnabled();
         if (this.currentPlan != null) {
            if (diagnosticsEnabled) {
               for (Plan<T> plan : context.plans()) {
                  diagnostics.recordPlanEvent(
                     context.agent().getTick(),
                     DiagnosticEventKind.PLAN_REJECTED,
                     plan,
                     AgentDiagnostics.details(DiagnosticDetailKeys.REASON.detail(DiagnosticReason.EXECUTOR_ALREADY_HAS_PLAN))
                  );
               }
            }
         } else {
            this.currentPlan = this.selectBestPlan(context.plans(), context.actor(), context.worldState());
            if (diagnosticsEnabled) {
               diagnostics.recordPlanEvent(
                  context.agent().getTick(),
                  DiagnosticEventKind.PLAN_ACCEPTED,
                  this.currentPlan,
                  AgentDiagnostics.details(DiagnosticDetailKeys.REASON.detail(DiagnosticReason.BEST_PLAN))
               );

               for (Plan<T> plan : context.plans()) {
                  if (plan != this.currentPlan) {
                     diagnostics.recordPlanEvent(
                        context.agent().getTick(),
                        DiagnosticEventKind.PLAN_REJECTED,
                        plan,
                        AgentDiagnostics.details(DiagnosticDetailKeys.REASON.detail(DiagnosticReason.LOWER_SCORE))
                     );
                  }
               }
            }
         }
      }
   }

   @Override
   public boolean hasActivePlans() {
      return this.currentPlan != null;
   }

   @Override
   public void abandonAllPlans() {
      this.currentPlan = null;
   }

   @Nullable
   public Plan<T> getCurrentPlan() {
      return this.currentPlan;
   }

   private Plan<T> selectBestPlan(List<Plan<T>> plans, T actor, ReadableWorldState worldState) {
      Plan<T> bestPlan = null;
      float bestScore = -1.0F;

      for (Plan<T> plan : plans) {
         float score = this.planScorer.score(plan, actor, worldState, plans);
         if (score > bestScore) {
            bestScore = score;
            bestPlan = plan;
         }
      }

      return bestPlan == null ? plans.getFirst() : bestPlan;
   }
}
