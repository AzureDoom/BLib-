package com.just.ai.goap.goal;

import com.just.ai.goap.StateKey;
import com.just.ai.goap.condition.Condition;
import com.just.ai.goap.condition.ConditionContainer;
import com.just.ai.goap.condition.expression.Expression;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.UnaryOperator;

public class BaseGoal implements Goal {
   private final ConditionContainer desiredConditions;
   private final String name;
   private final ConditionContainer preconditions;

   public static BaseGoal.ConcreteBuilder builder(String name) {
      return new BaseGoal.ConcreteBuilder(name);
   }

   protected BaseGoal(String name, ConditionContainer desiredConditions, ConditionContainer preconditions) {
      this.name = name;
      this.desiredConditions = desiredConditions;
      this.preconditions = preconditions;
   }

   @Override
   public ConditionContainer getDesiredConditions() {
      return this.desiredConditions;
   }

   @Override
   public String getName() {
      return this.name;
   }

   @Override
   public ConditionContainer getPreconditions() {
      return this.preconditions;
   }

   @Override
   public String toString() {
      return this.getName();
   }

   public abstract static class Builder<B extends BaseGoal.Builder<B>> {
      protected final List<Condition.Derived<?>> desiredConditions = new ArrayList<>();
      protected final List<Condition.Sensed<?>> preconditions = new ArrayList<>();
      protected String name;

      protected Builder(String name) {
         this.name = name;
      }

      protected abstract B self();

      public <U> B addDesiredCondition(StateKey.Derived<? extends U> key, Expression<? super U> expression) {
         return this.addDesiredCondition(Condition.derived(key, expression));
      }

      public <U> B addDesiredCondition(Condition.Derived<U> condition) {
         this.desiredConditions.add(condition);
         return this.self();
      }

      public <U> B addPrecondition(StateKey.Sensed<? extends U> key, Expression<? super U> expression) {
         return this.addPrecondition(Condition.sensed(key, expression));
      }

      public <U> B addPrecondition(Condition.Sensed<U> condition) {
         this.preconditions.add(condition);
         return this.self();
      }

      public B withName(String name) {
         this.name = name;
         return this.self();
      }

      public B apply(UnaryOperator<B> unaryOperator) {
         return unaryOperator.apply(this.self());
      }

      public BaseGoal build() {
         if (this.desiredConditions.isEmpty()) {
            throw new IllegalStateException("Goal must have at least one desired condition.");
         } else {
            return new BaseGoal(
               this.name,
               ConditionContainer.of(Collections.unmodifiableList(this.desiredConditions)),
               ConditionContainer.of(Collections.unmodifiableList(this.preconditions))
            );
         }
      }
   }

   public static class ConcreteBuilder extends BaseGoal.Builder<BaseGoal.ConcreteBuilder> {
      protected ConcreteBuilder(String name) {
         super(name);
      }

      protected BaseGoal.ConcreteBuilder self() {
         return this;
      }
   }
}
