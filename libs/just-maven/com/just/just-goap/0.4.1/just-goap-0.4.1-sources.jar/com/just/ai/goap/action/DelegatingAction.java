package com.just.ai.goap.action;

import com.just.ai.goap.StateKey;
import com.just.ai.goap.condition.Condition;
import com.just.ai.goap.condition.ConditionContainer;
import com.just.ai.goap.condition.expression.Expression;
import com.just.ai.goap.effect.Effect;
import com.just.ai.goap.effect.EffectContainer;
import com.just.ai.goap.state.ReadableWorldState;
import java.util.function.UnaryOperator;

public abstract class DelegatingAction<T> implements Action<T> {
   private final Action<T> delegate;

   protected DelegatingAction(Action<T> delegate) {
      this.delegate = delegate;
   }

   public Action<T> getDelegate() {
      return this.delegate;
   }

   @Override
   public float getCost(T actor, ReadableWorldState worldState) {
      return this.delegate.getCost(actor, worldState);
   }

   @Override
   public Action.Signal perform(Action.Context<? extends T> context) {
      return this.delegate.perform(context);
   }

   @Override
   public void onStart(Action.Context<? extends T> context) {
      this.delegate.onStart(context);
   }

   @Override
   public void onFinish(Action.Context<? extends T> context) {
      this.delegate.onFinish(context);
   }

   @Override
   public ConditionContainer getPreconditionContainer() {
      return this.delegate.getPreconditionContainer();
   }

   @Override
   public ConditionContainer getPlanTimePreconditionContainer() {
      return this.delegate.getPlanTimePreconditionContainer();
   }

   @Override
   public ConditionContainer getRuntimePreconditionContainer() {
      return this.delegate.getRuntimePreconditionContainer();
   }

   @Override
   public EffectContainer getEffectContainer() {
      return this.delegate.getEffectContainer();
   }

   @Override
   public String getName() {
      return this.delegate.getName();
   }

   @Override
   public String toString() {
      return this.delegate.toString();
   }

   public abstract static class Builder<T, B extends DelegatingAction.Builder<T, B>> {
      protected final BaseAction.ConcreteBuilder<T> baseBuilder;

      protected Builder(String name) {
         this.baseBuilder = BaseAction.builder(name);
      }

      protected abstract B self();

      protected abstract DelegatingAction<T> build(Action<T> var1);

      public <U> B addPrecondition(StateKey.Derived<? extends U> key, Expression<? super U> expression) {
         this.baseBuilder.addPrecondition(key, expression);
         return this.self();
      }

      public <U> B addPrecondition(StateKey.Sensed<? extends U> key, Expression<? super U> expression) {
         this.baseBuilder.addPrecondition(key, expression);
         return this.self();
      }

      public B addPrecondition(Condition<?> condition) {
         this.baseBuilder.addPrecondition(condition);
         return this.self();
      }

      public <U> B addPlanTimePrecondition(StateKey.Derived<? extends U> key, Expression<? super U> expression) {
         this.baseBuilder.addPlanTimePrecondition(key, expression);
         return this.self();
      }

      public <U> B addPlanTimePrecondition(StateKey.Sensed<? extends U> key, Expression<? super U> expression) {
         this.baseBuilder.addPlanTimePrecondition(key, expression);
         return this.self();
      }

      public B addPlanTimePrecondition(Condition<?> condition) {
         this.baseBuilder.addPlanTimePrecondition(condition);
         return this.self();
      }

      public <U> B addRuntimePrecondition(StateKey.Derived<? extends U> key, Expression<? super U> expression) {
         this.baseBuilder.addRuntimePrecondition(key, expression);
         return this.self();
      }

      public <U> B addRuntimePrecondition(StateKey.Sensed<? extends U> key, Expression<? super U> expression) {
         this.baseBuilder.addRuntimePrecondition(key, expression);
         return this.self();
      }

      public B addRuntimePrecondition(Condition<?> condition) {
         this.baseBuilder.addRuntimePrecondition(condition);
         return this.self();
      }

      public <U> B addEffect(StateKey.Derived<U> key, UnaryOperator<U> consumer) {
         this.baseBuilder.addEffect(key, consumer);
         return this.self();
      }

      public <U> B addEffect(StateKey.Derived<U> key, U value) {
         this.baseBuilder.addEffect(key, value);
         return this.self();
      }

      public B addEffect(Effect<?> effect) {
         this.baseBuilder.addEffect(effect);
         return this.self();
      }

      public B withName(String name) {
         this.baseBuilder.withName(name);
         return this.self();
      }

      public B withCost(float cost) {
         return this.withCostCallback(($1, $2) -> cost);
      }

      public B withCostCallback(Action.CostCallback<T> costCallback) {
         this.baseBuilder.withCostCallback(costCallback);
         return this.self();
      }

      public B withStartCallback(Action.StartCallback<T> startCallback) {
         this.baseBuilder.withStartCallback(startCallback);
         return this.self();
      }

      public B withPerformCallback(Action.PerformCallback<T> performCallback) {
         this.baseBuilder.withPerformCallback(performCallback);
         return this.self();
      }

      public B withFinishCallback(Action.FinishCallback<T> finishCallback) {
         this.baseBuilder.withFinishCallback(finishCallback);
         return this.self();
      }

      public B apply(UnaryOperator<B> unaryOperator) {
         return unaryOperator.apply(this.self());
      }

      public DelegatingAction<T> build() {
         BaseAction<T> baseAction = this.baseBuilder.build();
         return this.build(baseAction);
      }
   }
}
