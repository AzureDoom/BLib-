package com.just.ai.goap.debug;

import java.util.List;

public record AgentDiagnosticsSnapshot(long tick, List<PlanSearchResult> planSearches, List<PlanExecutionEvent> events) {
   public AgentDiagnosticsSnapshot(long tick, List<PlanSearchResult> planSearches, List<PlanExecutionEvent> events) {
      planSearches = List.copyOf(planSearches);
      events = List.copyOf(events);
      this.tick = tick;
      this.planSearches = planSearches;
      this.events = events;
   }
}
