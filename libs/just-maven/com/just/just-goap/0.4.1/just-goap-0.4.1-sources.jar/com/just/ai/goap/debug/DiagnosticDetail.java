package com.just.ai.goap.debug;

import java.util.Objects;

public record DiagnosticDetail<T>(DiagnosticDetailKey<T> key, T value) {
   public DiagnosticDetail(DiagnosticDetailKey<T> key, T value) {
      key = Objects.requireNonNull(key, "key");
      if (value != null && !key.type().isInstance(value)) {
         throw new IllegalArgumentException("Detail value for '%s' must be a %s".formatted(key.id(), key.type().getName()));
      } else {
         this.key = key;
         this.value = value;
      }
   }

   public String displayValue() {
      return this.value instanceof Enum<?> enumValue ? enumValue.name() : String.valueOf(this.value);
   }
}
