package com.just.ai.goap.debug;

import java.util.List;

public record ConditionSummaries(List<String> conditions) {
   public ConditionSummaries(List<String> conditions) {
      conditions = List.copyOf(conditions);
      this.conditions = conditions;
   }
}
