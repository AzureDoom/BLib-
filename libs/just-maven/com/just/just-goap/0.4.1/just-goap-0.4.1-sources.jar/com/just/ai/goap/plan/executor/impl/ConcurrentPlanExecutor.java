package com.just.ai.goap.plan.executor.impl;

import com.just.ai.goap.Agent;
import com.just.ai.goap.debug.AgentDiagnostics;
import com.just.ai.goap.debug.DiagnosticDetailKeys;
import com.just.ai.goap.debug.DiagnosticEventKind;
import com.just.ai.goap.debug.DiagnosticReason;
import com.just.ai.goap.plan.Plan;
import com.just.ai.goap.plan.PlanComparator;
import com.just.ai.goap.plan.executor.PlanExecutor;
import com.just.ai.goap.plan.scorer.PlanScorer;
import com.just.ai.goap.state.ReadableWorldState;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.function.UnaryOperator;

public class ConcurrentPlanExecutor<T> implements PlanExecutor<T> {
   private final List<Plan<T>> activePlans = new ArrayList<>();
   private final ConcurrentPlanExecutor.PlanResolver<T> planResolver;
   private final int maxConcurrentPlans;

   public static <T> ConcurrentPlanExecutor.Builder<T> builder() {
      return new ConcurrentPlanExecutor.Builder<>();
   }

   public static <T> ConcurrentPlanExecutor<T> create() {
      return new ConcurrentPlanExecutor<>(ConcurrentPlanExecutor.PlanResolver.preferCheaperSameGoal(), Integer.MAX_VALUE);
   }

   private ConcurrentPlanExecutor(ConcurrentPlanExecutor.PlanResolver<T> planResolver, int maxConcurrentPlans) {
      this.planResolver = planResolver;
      this.maxConcurrentPlans = maxConcurrentPlans;
   }

   @Override
   public PlanExecutor.Result execute(PlanExecutor.ExecutionContext<T> context) {
      if (this.activePlans.isEmpty()) {
         return PlanExecutor.Result.NO_PLANS;
      } else {
         Agent.Debugger timings = context.agent().getDebug().getTimings();
         AgentDiagnostics diagnostics = context.agent().getDebug().getDiagnostics();
         boolean diagnosticsEnabled = diagnostics.isEnabled();
         timings.push("ConcurrentPlanExecutor.execute()");
         Iterator<Plan<T>> iterator = this.activePlans.iterator();
         boolean anyInProgress = false;

         while (iterator.hasNext()) {
            Plan<T> plan = iterator.next();
            Plan.State planState = plan.update(context.agent(), context.actor(), context.currentWorldState(), context.previousWorldState());
            switch (planState) {
               case ABORTED:
               case FINISHED:
               case INVALID:
                  if (diagnosticsEnabled) {
                     diagnostics.recordPlanEvent(
                        context.agent().getTick(),
                        DiagnosticEventKind.PLAN_REMOVED,
                        plan,
                        AgentDiagnostics.details(DiagnosticDetailKeys.PLAN_STATE.detail(planState))
                     );
                  }

                  iterator.remove();
                  break;
               case IN_PROGRESS:
                  anyInProgress = true;
            }
         }

         timings.pop();
         return anyInProgress ? PlanExecutor.Result.IN_PROGRESS : PlanExecutor.Result.IDLE;
      }
   }

   @Override
   public void supplyPlans(List<Plan<T>> plans, T actor, ReadableWorldState worldState) {
      for (Plan<T> candidate : plans) {
         if (this.activePlans.size() >= this.maxConcurrentPlans) {
            break;
         }

         this.processCandidate(candidate, actor, worldState, null, -1L);
      }
   }

   @Override
   public void supplyPlans(PlanExecutor.SupplyContext<T> context) {
      AgentDiagnostics diagnostics = context.agent().getDebug().getDiagnostics();
      boolean diagnosticsEnabled = diagnostics.isEnabled();

      for (Plan<T> candidate : context.plans()) {
         if (this.activePlans.size() >= this.maxConcurrentPlans) {
            if (diagnosticsEnabled) {
               diagnostics.recordPlanEvent(
                  context.agent().getTick(),
                  DiagnosticEventKind.PLAN_REJECTED,
                  candidate,
                  AgentDiagnostics.details(DiagnosticDetailKeys.REASON.detail(DiagnosticReason.MAX_CONCURRENT_PLANS))
               );
            }
            break;
         }

         this.processCandidate(candidate, context.actor(), context.worldState(), diagnosticsEnabled ? diagnostics : null, context.agent().getTick());
      }
   }

   private void processCandidate(Plan<T> candidate, T actor, ReadableWorldState worldState, AgentDiagnostics diagnostics, long tick) {
      List<Plan<T>> toRemove = null;
      boolean acceptCandidate = true;
      DiagnosticReason rejectionReason = null;

      for (Plan<T> active : this.activePlans) {
         ConcurrentPlanExecutor.PlanResolver.Resolution resolution = this.planResolver.resolve(active, candidate, actor, worldState);
         switch (resolution) {
            case KEEP_ACTIVE:
               acceptCandidate = false;
               rejectionReason = DiagnosticReason.CONFLICT_KEEP_ACTIVE;
               break;
            case REPLACE_ACTIVE:
               if (toRemove == null) {
                  toRemove = new ArrayList<>();
               }

               toRemove.add(active);
               break;
            case REJECT_BOTH:
               acceptCandidate = false;
               rejectionReason = DiagnosticReason.CONFLICT_REJECT_BOTH;
               if (toRemove == null) {
                  toRemove = new ArrayList<>();
               }

               toRemove.add(active);
            case NO_CONFLICT:
         }

         if (!acceptCandidate && resolution != ConcurrentPlanExecutor.PlanResolver.Resolution.REJECT_BOTH) {
            break;
         }
      }

      if (toRemove != null) {
         this.activePlans.removeAll(toRemove);
         if (diagnostics != null) {
            for (Plan<T> removed : toRemove) {
               diagnostics.recordPlanEvent(
                  tick,
                  DiagnosticEventKind.PLAN_REMOVED,
                  removed,
                  AgentDiagnostics.details(
                     DiagnosticDetailKeys.REASON.detail(acceptCandidate ? DiagnosticReason.REPLACED_BY_CANDIDATE : DiagnosticReason.CONFLICT_REJECT_BOTH),
                     DiagnosticDetailKeys.CANDIDATE_PLAN_ID.detail(candidate.getId())
                  )
               );
            }
         }
      }

      if (acceptCandidate && this.activePlans.size() < this.maxConcurrentPlans) {
         this.activePlans.add(candidate);
         if (diagnostics != null) {
            diagnostics.recordPlanEvent(
               tick,
               DiagnosticEventKind.PLAN_ACCEPTED,
               candidate,
               AgentDiagnostics.details(DiagnosticDetailKeys.REASON.detail(toRemove == null ? DiagnosticReason.ACCEPTED : DiagnosticReason.REPLACED_ACTIVE))
            );
         }
      } else if (diagnostics != null) {
         diagnostics.recordPlanEvent(
            tick,
            DiagnosticEventKind.PLAN_REJECTED,
            candidate,
            AgentDiagnostics.details(DiagnosticDetailKeys.REASON.detail(rejectionReason == null ? DiagnosticReason.NOT_ACCEPTED : rejectionReason))
         );
      }
   }

   @Override
   public boolean hasActivePlans() {
      return !this.activePlans.isEmpty();
   }

   @Override
   public void abandonAllPlans() {
      this.activePlans.clear();
   }

   public List<Plan<T>> getActivePlans() {
      return Collections.unmodifiableList(this.activePlans);
   }

   public int getActivePlanCount() {
      return this.activePlans.size();
   }

   public int getMaxConcurrentPlans() {
      return this.maxConcurrentPlans;
   }

   public ConcurrentPlanExecutor.PlanResolver<T> getPlanResolver() {
      return this.planResolver;
   }

   public static class Builder<T> {
      private ConcurrentPlanExecutor.PlanResolver<T> planResolver = ConcurrentPlanExecutor.PlanResolver.preferCheaperSameGoal();
      private int maxConcurrentPlans = Integer.MAX_VALUE;

      private Builder() {
      }

      public ConcurrentPlanExecutor.Builder<T> withPlanResolver(ConcurrentPlanExecutor.PlanResolver<T> planResolver) {
         this.planResolver = planResolver;
         return this;
      }

      public ConcurrentPlanExecutor.Builder<T> withMaxConcurrentPlans(int maxConcurrentPlans) {
         if (maxConcurrentPlans < 1) {
            throw new IllegalArgumentException("maxConcurrentPlans must be at least 1");
         } else {
            this.maxConcurrentPlans = maxConcurrentPlans;
            return this;
         }
      }

      public ConcurrentPlanExecutor.Builder<T> apply(UnaryOperator<ConcurrentPlanExecutor.Builder<T>> unaryOperator) {
         return unaryOperator.apply(this);
      }

      public ConcurrentPlanExecutor<T> build() {
         return new ConcurrentPlanExecutor<>(this.planResolver, this.maxConcurrentPlans);
      }
   }

   @FunctionalInterface
   public interface PlanResolver<T> {
      static <T> ConcurrentPlanExecutor.PlanResolver<T> allowAll() {
         return (ConcurrentPlanExecutor.PlanResolver<T>) (ConcurrentPlanExecutor.PlanResolver<?>) ConcurrentPlanExecutor.PlanResolver.AllowAll.INSTANCE;
      }

      static <T> ConcurrentPlanExecutor.PlanResolver<T> rejectSameGoal() {
         return (ConcurrentPlanExecutor.PlanResolver<T>) (ConcurrentPlanExecutor.PlanResolver<?>) ConcurrentPlanExecutor.PlanResolver.RejectSameGoal.INSTANCE;
      }

      static <T> ConcurrentPlanExecutor.PlanResolver<T> preferCheaperSameGoal() {
         return (ConcurrentPlanExecutor.PlanResolver<T>) (ConcurrentPlanExecutor.PlanResolver<?>) ConcurrentPlanExecutor.PlanResolver.PreferCheaperSameGoal.INSTANCE;
      }

      static <T> ConcurrentPlanExecutor.PlanResolver<T> preferHigherScore(PlanScorer<T> scorer) {
         return (active, candidate, actor, worldState) -> {
            if (!PlanComparator.hasSameGoal(active, candidate)) {
               return ConcurrentPlanExecutor.PlanResolver.Resolution.NO_CONFLICT;
            } else {
               List<Plan<T>> allPlans = List.of(active, candidate);
               float activeScore = scorer.score(active, actor, worldState, allPlans);
               float candidateScore = scorer.score(candidate, actor, worldState, allPlans);
               return candidateScore > activeScore
                  ? ConcurrentPlanExecutor.PlanResolver.Resolution.REPLACE_ACTIVE
                  : ConcurrentPlanExecutor.PlanResolver.Resolution.KEEP_ACTIVE;
            }
         };
      }

      ConcurrentPlanExecutor.PlanResolver.Resolution resolve(Plan<T> var1, Plan<T> var2, T var3, ReadableWorldState var4);

      public static enum AllowAll implements ConcurrentPlanExecutor.PlanResolver<Object> {
         INSTANCE;

         @Override
         public ConcurrentPlanExecutor.PlanResolver.Resolution resolve(Plan<Object> active, Plan<Object> candidate, Object actor, ReadableWorldState worldState) {
            return ConcurrentPlanExecutor.PlanResolver.Resolution.NO_CONFLICT;
         }
      }

      public static enum PreferCheaperSameGoal implements ConcurrentPlanExecutor.PlanResolver<Object> {
         INSTANCE;

         @Override
         public ConcurrentPlanExecutor.PlanResolver.Resolution resolve(Plan<Object> active, Plan<Object> candidate, Object actor, ReadableWorldState worldState) {
            if (!PlanComparator.hasSameGoal(active, candidate)) {
               return ConcurrentPlanExecutor.PlanResolver.Resolution.NO_CONFLICT;
            } else {
               float activeRemainingCost = active.getRemainingCost(actor, worldState);
               float candidateCost = candidate.getInitialCost();
               return candidateCost < activeRemainingCost
                  ? ConcurrentPlanExecutor.PlanResolver.Resolution.REPLACE_ACTIVE
                  : ConcurrentPlanExecutor.PlanResolver.Resolution.KEEP_ACTIVE;
            }
         }
      }

      public static enum RejectSameGoal implements ConcurrentPlanExecutor.PlanResolver<Object> {
         INSTANCE;

         @Override
         public ConcurrentPlanExecutor.PlanResolver.Resolution resolve(Plan<Object> active, Plan<Object> candidate, Object actor, ReadableWorldState worldState) {
            return PlanComparator.hasSameGoal(active, candidate)
               ? ConcurrentPlanExecutor.PlanResolver.Resolution.KEEP_ACTIVE
               : ConcurrentPlanExecutor.PlanResolver.Resolution.NO_CONFLICT;
         }
      }

      public static enum Resolution {
         KEEP_ACTIVE,
         REPLACE_ACTIVE,
         REJECT_BOTH,
         NO_CONFLICT;
      }
   }
}
