package com.just.ai.goap.debug;

import com.just.ai.goap.action.Action;
import com.just.ai.goap.plan.Plan;
import com.just.ai.goap.plan.ReplanDecisions;
import com.just.ai.goap.plan.ReplanReason;

public final class DiagnosticDetailKeys {
   public static final DiagnosticDetailKey<Integer> PLAN_COUNT = DiagnosticDetailKey.of("plan_count", Integer.class);
   public static final DiagnosticDetailKey<PlanSummaries> PLAN_SUMMARIES = DiagnosticDetailKey.of("plan_summaries", PlanSummaries.class);
   public static final DiagnosticDetailKey<Plan.State> PLAN_STATE = DiagnosticDetailKey.of("plan_state", Plan.State.class);
   public static final DiagnosticDetailKey<DiagnosticReason> REASON = DiagnosticDetailKey.of("reason", DiagnosticReason.class);
   public static final DiagnosticDetailKey<Long> CANDIDATE_PLAN_ID = DiagnosticDetailKey.of("candidate_plan_id", Long.class);
   public static final DiagnosticDetailKey<Action.Signal> SIGNAL = DiagnosticDetailKey.of("signal", Action.Signal.class);
   public static final DiagnosticDetailKey<ConditionSummaries> MISSING_RUNTIME_CONDITIONS = DiagnosticDetailKey.of(
      "missing_runtime_conditions", ConditionSummaries.class
   );
   public static final DiagnosticDetailKey<ReplanReason> REPLAN_REASON = DiagnosticDetailKey.of("replan_reason", ReplanReason.class);
   public static final DiagnosticDetailKey<Boolean> SHOULD_REPLAN = DiagnosticDetailKey.of("should_replan", Boolean.class);
   public static final DiagnosticDetailKey<ReplanDecisions> REPLAN_CHILD_DECISIONS = DiagnosticDetailKey.of("replan_child_decisions", ReplanDecisions.class);

   private DiagnosticDetailKeys() {
      throw new UnsupportedOperationException();
   }
}
