package com.just.ai.goap;

import com.just.ai.goap.effect.EffectContainer;
import com.just.ai.goap.state.ReadableWorldState;

public interface Satisfiable {
   boolean satisfiedBy(ReadableWorldState var1);

   default boolean satisfiedBy(EffectContainer effectContainer) {
      return this.satisfiedBy(effectContainer.toWorldState());
   }
}
