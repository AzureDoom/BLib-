package com.just.ai.goap.debug;

import java.util.List;

public record PlanSummary(long id, String goalName, List<String> actions, float initialCost) {
   public PlanSummary(long id, String goalName, List<String> actions, float initialCost) {
      actions = List.copyOf(actions);
      this.id = id;
      this.goalName = goalName;
      this.actions = actions;
      this.initialCost = initialCost;
   }

   static PlanSummary none() {
      return new PlanSummary(-1L, "", List.of(), 0.0F);
   }
}
