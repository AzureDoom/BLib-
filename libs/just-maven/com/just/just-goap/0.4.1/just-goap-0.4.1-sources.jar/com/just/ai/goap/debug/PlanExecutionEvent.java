package com.just.ai.goap.debug;

import java.util.List;
import java.util.Optional;

public record PlanExecutionEvent(long tick, DiagnosticEventKind kind, PlanSummary plan, int actionIndex, String actionName, List<DiagnosticDetail<?>> details) {
   public PlanExecutionEvent(long tick, DiagnosticEventKind kind, PlanSummary plan, int actionIndex, String actionName, List<DiagnosticDetail<?>> details) {
      details = List.copyOf(details);
      this.tick = tick;
      this.kind = kind;
      this.plan = plan;
      this.actionIndex = actionIndex;
      this.actionName = actionName;
      this.details = details;
   }

   public <T> Optional<T> detail(DiagnosticDetailKey<T> key) {
      for (DiagnosticDetail<?> detail : this.details) {
         if (detail.key().equals(key)) {
            return Optional.ofNullable(key.type().cast(detail.value()));
         }
      }

      return Optional.empty();
   }
}
