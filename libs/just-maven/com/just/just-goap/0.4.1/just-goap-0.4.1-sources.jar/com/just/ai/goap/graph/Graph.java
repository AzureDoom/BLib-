package com.just.ai.goap.graph;

import com.just.ai.goap.StateKey;
import com.just.ai.goap.action.Action;
import com.just.ai.goap.condition.Condition;
import com.just.ai.goap.effect.EffectContainer;
import com.just.ai.goap.goal.Goal;
import com.just.ai.goap.sensor.Sensor;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.UnaryOperator;

public class Graph<T> {
   private final Set<Action<? super T>> availableActions;
   private final Set<Goal> availableGoals;
   private final Map<Condition<?>, Set<Action<? super T>>> preconditionToSatisfyingActionsMap;
   private final Map<StateKey<?>, Sensor<? super T>> sensorMap;

   public static <T> Graph.Builder<T> builder() {
      return new Graph.Builder<>();
   }

   private Graph(
      Set<Action<? super T>> availableActions,
      Set<Goal> availableGoals,
      Map<Condition<?>, Set<Action<? super T>>> preconditionToSatisfyingActionsMap,
      Map<StateKey<?>, Sensor<? super T>> sensorMap
   ) {
      this.availableActions = availableActions;
      this.availableGoals = availableGoals;
      this.preconditionToSatisfyingActionsMap = preconditionToSatisfyingActionsMap;
      this.sensorMap = sensorMap;
   }

   public Set<Action<? super T>> getAvailableActions() {
      return this.availableActions;
   }

   public Set<Goal> getAvailableGoals() {
      return this.availableGoals;
   }

   public Set<Action<? super T>> getActionsThatSatisfy(Condition<?> condition) {
      return this.preconditionToSatisfyingActionsMap.getOrDefault(condition, Set.of());
   }

   public Map<StateKey<?>, Sensor<? super T>> getSensorMap() {
      return this.sensorMap;
   }

   public Graph.Builder<T> toBuilder() {
      Graph.Builder<T> builder = builder();
      this.availableGoals.forEach(builder::addGoal);
      this.availableActions.forEach(builder::addAction);
      this.sensorMap.values().forEach(builder::addSensor);
      return builder;
   }

   public static class Builder<T> {
      private final Set<Action<? super T>> availableActions = new HashSet<>();
      private final Set<Goal> availableGoals = new HashSet<>();
      private final Map<Condition<?>, Set<Action<? super T>>> preconditionToSatisfyingActionsMap = new HashMap<>();
      private final Map<StateKey<?>, Sensor<? super T>> sensorMap = new HashMap<>();

      private Builder() {
      }

      public Graph.Builder<T> addSensors(Collection<? extends Sensor<? super T>> sensors) {
         sensors.forEach(this::addSensor);
         return this;
      }

      public Graph.Builder<T> addSensor(Sensor<? super T> sensor) {
         sensor.outputKeys().forEach(key -> this.sensorMap.put(key, sensor));
         return this;
      }

      public Graph.Builder<T> addGoals(Collection<Goal> goals) {
         goals.forEach(this::addGoal);
         return this;
      }

      public Graph.Builder<T> addGoal(Goal goal) {
         List<Condition<?>> desiredConditions = goal.getDesiredConditions().getConditions();
         if (desiredConditions.isEmpty()) {
            throw new IllegalArgumentException("Goal must specify at least one desired condition: " + goal);
         } else {
            this.availableGoals.add(goal);

            for (Condition<?> condition : desiredConditions) {
               Set<Action<? super T>> actions = this.preconditionToSatisfyingActionsMap.computeIfAbsent(condition, $ -> new HashSet<>());

               for (Action<? super T> action : this.availableActions) {
                  if (condition.satisfiedBy(action.getEffectContainer())) {
                     actions.add(action);
                  }
               }
            }

            return this;
         }
      }

      public Graph.Builder<T> addActions(Collection<Action<? super T>> actions) {
         actions.forEach(this::addAction);
         return this;
      }

      public Graph.Builder<T> addAction(Action<? super T> action) {
         if (action.getEffectContainer().getEffects().isEmpty()) {
            throw new IllegalArgumentException("Action must have at least one effect: " + action);
         } else {
            this.availableActions.add(action);
            EffectContainer effects = action.getEffectContainer();
            HashSet<Condition<?>> newPreconditions = new HashSet<>();

            for (Condition<?> precondition : action.getPreconditionContainer().getConditions()) {
               this.preconditionToSatisfyingActionsMap.computeIfAbsent(precondition, $ -> {
                  newPreconditions.add(precondition);
                  return new HashSet<>();
               });
            }

            for (Condition<?> condition : this.preconditionToSatisfyingActionsMap.keySet()) {
               if (condition.satisfiedBy(effects)) {
                  Set<Action<? super T>> actions = this.preconditionToSatisfyingActionsMap.get(condition);
                  actions.add(action);
               }
            }

            for (Condition<?> newPrecondition : newPreconditions) {
               Set<Action<? super T>> actions = this.preconditionToSatisfyingActionsMap.get(newPrecondition);

               for (Action<? super T> otherAction : this.availableActions) {
                  if (otherAction != action && newPrecondition.satisfiedBy(otherAction.getEffectContainer())) {
                     actions.add(otherAction);
                  }
               }
            }

            return this;
         }
      }

      public Graph.Builder<T> apply(UnaryOperator<Graph.Builder<T>> unaryOperator) {
         return unaryOperator.apply(this);
      }

      public Graph<T> build() {
         GraphValidator.validate(this.availableActions, this.availableGoals, this.preconditionToSatisfyingActionsMap, this.sensorMap);
         return new Graph<>(
            Collections.unmodifiableSet(this.availableActions),
            Collections.unmodifiableSet(this.availableGoals),
            Collections.unmodifiableMap(this.preconditionToSatisfyingActionsMap),
            Collections.unmodifiableMap(this.sensorMap)
         );
      }
   }
}
