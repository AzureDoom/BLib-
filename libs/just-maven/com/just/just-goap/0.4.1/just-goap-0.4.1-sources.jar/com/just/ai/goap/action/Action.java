package com.just.ai.goap.action;

import com.just.ai.goap.Agent;
import com.just.ai.goap.condition.ConditionContainer;
import com.just.ai.goap.debug.DiagnosticDetail;
import com.just.ai.goap.debug.DiagnosticDetailKey;
import com.just.ai.goap.effect.EffectContainer;
import com.just.ai.goap.plan.Plan;
import com.just.ai.goap.state.Blackboard;
import com.just.ai.goap.state.ReadableWorldState;
import java.util.ArrayList;
import java.util.List;

public interface Action<T> {
   static <T> BaseAction.ConcreteBuilder<T> builder(String name) {
      return BaseAction.builder(name);
   }

   float getCost(T var1, ReadableWorldState var2);

   Action.Signal perform(Action.Context<? extends T> var1);

   void onStart(Action.Context<? extends T> var1);

   void onFinish(Action.Context<? extends T> var1);

   ConditionContainer getPreconditionContainer();

   ConditionContainer getPlanTimePreconditionContainer();

   ConditionContainer getRuntimePreconditionContainer();

   EffectContainer getEffectContainer();

   String getName();

   public static final class Context<T> {
      private Action<T> action;
      private T actor;
      private Agent<T> agent;
      private Blackboard blackboard;
      private Plan<T> plan;
      private ReadableWorldState worldState;
      private ReadableWorldState previousWorldState;
      private final List<DiagnosticDetail<?>> debugDetails = new ArrayList<>();
      private boolean debugDetailsEnabled = true;

      public Action<T> getAction() {
         return this.action;
      }

      public T getActor() {
         return this.actor;
      }

      public Agent<T> getAgent() {
         return this.agent;
      }

      public Blackboard getBlackboard(Blackboard.Scope scope) {
         return switch (scope) {
            case ACTION -> this.blackboard;
            case AGENT -> this.agent.getBlackboard();
            case GRAPH -> this.agent.getGraphBlackboard();
            case PLAN -> this.plan.getBlackboard();
         };
      }

      public Plan<T> getPlan() {
         return this.plan;
      }

      public ReadableWorldState getWorldState() {
         return this.worldState;
      }

      public ReadableWorldState getPreviousWorldState() {
         return this.previousWorldState;
      }

      public boolean isDebugDetailsEnabled() {
         return this.debugDetailsEnabled;
      }

      public <V> void putDebugDetail(DiagnosticDetailKey<V> key, V value) {
         if (this.debugDetailsEnabled) {
            this.debugDetails.add(key.detail(value));
         }
      }

      public void putDebugDetail(DiagnosticDetail<?> detail) {
         if (this.debugDetailsEnabled) {
            this.debugDetails.add(detail);
         }
      }

      public List<DiagnosticDetail<?>> getDebugDetails() {
         return !this.debugDetailsEnabled ? List.of() : List.copyOf(this.debugDetails);
      }

      public void clearDebugDetails() {
         this.debugDetails.clear();
      }

      public void set(
         Action<T> action, T actor, Agent<T> agent, Blackboard blackboard, Plan<T> plan, ReadableWorldState worldState, ReadableWorldState previousWorldState
      ) {
         this.set(action, actor, agent, blackboard, plan, worldState, previousWorldState, true);
      }

      public void set(
         Action<T> action,
         T actor,
         Agent<T> agent,
         Blackboard blackboard,
         Plan<T> plan,
         ReadableWorldState worldState,
         ReadableWorldState previousWorldState,
         boolean debugDetailsEnabled
      ) {
         this.action = action;
         this.actor = actor;
         this.agent = agent;
         this.blackboard = blackboard;
         this.plan = plan;
         this.worldState = worldState;
         this.previousWorldState = previousWorldState;
         this.debugDetailsEnabled = debugDetailsEnabled;
         this.clearDebugDetails();
      }
   }

   @FunctionalInterface
   public interface CostCallback<T> {
      float apply(T var1, ReadableWorldState var2);
   }

   @FunctionalInterface
   public interface FinishCallback<T> {
      void apply(Action.Context<? extends T> var1);
   }

   @FunctionalInterface
   public interface PerformCallback<T> {
      Action.Signal accept(Action.Context<? extends T> var1);
   }

   public static enum Signal {
      ABORT,
      CONTINUE;
   }

   @FunctionalInterface
   public interface StartCallback<T> {
      void apply(Action.Context<? extends T> var1);
   }
}
