package com.just.ai.goap.state;

import com.just.ai.goap.StateKey;
import com.just.ai.goap.effect.Effect;
import com.just.ai.goap.effect.EffectContainer;
import com.just.ai.goap.graph.Graph;
import com.just.ai.goap.sensor.Sensor;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The agent's live world state: values are sensed on first read and memoised.
 * <p>
 * 0.4.1 adds two optimisations, both switchable per agent through {@link #setOptimizationsEnabled} (the owning
 * {@link com.just.ai.goap.Agent} forwards its own setting every tick):
 * </p>
 * <ul>
 *    <li><b>A sensed {@code null} is memoised like any other value.</b> Before, {@code null} doubled as "not sensed yet",
 *    so a sensor that legitimately returned {@code null} ran again on every single read within the tick.</li>
 *    <li><b>Values from a sensor with {@link Sensor#refreshTicks()} above 1 survive {@link #advanceTick()}</b> for that
 *    many ticks instead of being discarded every tick. Every other value is discarded exactly as before.</li>
 * </ul>
 * <p>
 * With optimisations off this class behaves exactly as it did in 0.4.0.
 * </p>
 */
public final class SensingWorldState<T> implements WorldState {
   private static final Logger LOGGER = LoggerFactory.getLogger(SensingWorldState.class);
   private final Graph<T> graph;
   private final Map<StateKey<?>, Object> stateMap;
   private T actor;
   /** 0.4.1: the tick at which a held value expires, for keys whose sensor asked to be held. Absent = this tick only. */
   private final Map<StateKey<?>, Long> heldUntil;
   private boolean optimizationsEnabled;
   private long tick;

   public SensingWorldState(Graph<T> graph) {
      this.graph = graph;
      this.stateMap = new HashMap<>();
      this.heldUntil = new HashMap<>();
      this.optimizationsEnabled = true;
      this.tick = 0L;
   }

   @Override
   public <O> O getOrNull(StateKey<O> key) {
      O value = (O)this.stateMap.get(key);
      // ⚠ containsKey only matters when the stored value IS null: that is the "sensed, and it was null" case, which
      // 0.4.0 could not tell apart from "never sensed". The optimisation switch restores the old test.
      if (value == null && (!this.optimizationsEnabled || !this.stateMap.containsKey(key))) {
         Sensor<? super T> sensor = this.graph.getSensorMap().get(key);
         if (sensor != null) {
            value = sensor.apply(key, this.actor, this);
            this.stateMap.put(key, value);
            if (this.optimizationsEnabled) {
               int refreshTicks = sensor.refreshTicks();
               if (refreshTicks > 1) {
                  this.heldUntil.put(key, this.tick + refreshTicks);
               }
            }
         } else {
            LOGGER.warn("Attempted to sense a value for key '{}', but no sensor exists for key '{}'.", key, key);
         }
      }

      return value;
   }

   @Override
   public Map<StateKey<?>, Object> getMap() {
      return this.stateMap;
   }

   /**
    * Stores a value directly. A value set this way is never held across ticks, whatever its key's sensor asks for.
    */
   @Override
   public <U> void set(StateKey<U> key, U value) {
      this.stateMap.put(key, value);
      this.heldUntil.remove(key);
   }

   @Override
   public void setAll(Map<StateKey<?>, Object> map) {
      this.stateMap.putAll(map);
      for (StateKey<?> key : map.keySet()) {
         this.heldUntil.remove(key);
      }
   }

   @Override
   public void apply(EffectContainer effectContainer) {
      for (Effect<?> effect : effectContainer.getEffects()) {
         effect.apply(this);
      }
   }

   /**
    * Discards every value, held or not. This is the 0.4.0 per-tick reset.
    */
   @Override
   public void clear() {
      this.stateMap.clear();
      this.heldUntil.clear();
   }

   /**
    * 0.4.1: the per-tick reset used while optimisations are enabled. Moves to the next tick and discards every value
    * except those still inside their sensor's refresh window. With no sensor asking to be held, this discards exactly
    * what {@link #clear()} does.
    */
   public void advanceTick() {
      this.tick++;
      if (this.heldUntil.isEmpty()) {
         this.stateMap.clear();
         return;
      }

      Iterator<Map.Entry<StateKey<?>, Object>> entries = this.stateMap.entrySet().iterator();
      while (entries.hasNext()) {
         StateKey<?> key = entries.next().getKey();
         Long expiresAt = this.heldUntil.get(key);
         if (expiresAt == null || expiresAt <= this.tick) {
            entries.remove();
            if (expiresAt != null) {
               this.heldUntil.remove(key);
            }
         }
      }
   }

   public boolean isOptimizationsEnabled() {
      return this.optimizationsEnabled;
   }

   /**
    * 0.4.1: switches sensed-null memoisation and sensor refresh windows. Turning it off also drops every held value,
    * so the next read re-senses from scratch.
    */
   public void setOptimizationsEnabled(boolean optimizationsEnabled) {
      if (this.optimizationsEnabled && !optimizationsEnabled) {
         this.heldUntil.clear();
      }

      this.optimizationsEnabled = optimizationsEnabled;
   }

   public void setActor(T actor) {
      this.actor = actor;
   }

   @Override
   public String toString() {
      return "WorldState{stateMap=" + this.getMap() + "}";
   }

   public Graph<T> getGraph() {
      return this.graph;
   }
}
