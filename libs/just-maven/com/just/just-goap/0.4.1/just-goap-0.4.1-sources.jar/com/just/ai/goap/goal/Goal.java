package com.just.ai.goap.goal;

import com.just.ai.goap.condition.ConditionContainer;

public interface Goal {
   static BaseGoal.ConcreteBuilder builder(String name) {
      return BaseGoal.builder(name);
   }

   ConditionContainer getDesiredConditions();

   String getName();

   ConditionContainer getPreconditions();
}
