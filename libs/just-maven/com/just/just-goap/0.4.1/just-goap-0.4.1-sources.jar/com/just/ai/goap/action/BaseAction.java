package com.just.ai.goap.action;

import com.just.ai.goap.StateKey;
import com.just.ai.goap.condition.Condition;
import com.just.ai.goap.condition.ConditionContainer;
import com.just.ai.goap.condition.expression.Expression;
import com.just.ai.goap.effect.Effect;
import com.just.ai.goap.effect.EffectContainer;
import com.just.ai.goap.state.ReadableWorldState;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.UnaryOperator;

public class BaseAction<T> implements Action<T> {
   private final ConditionContainer planTimePreconditions;
   private final ConditionContainer runtimePreconditions;
   private final EffectContainer effects;
   private final Action.CostCallback<T> costCallback;
   private final Action.StartCallback<T> startCallback;
   private final Action.PerformCallback<T> performCallback;
   private final Action.FinishCallback<T> finishCallback;
   private final String name;

   public static <T> BaseAction.ConcreteBuilder<T> builder(String name) {
      return new BaseAction.ConcreteBuilder<>(name);
   }

   protected BaseAction(
      String name,
      ConditionContainer planTimePreconditions,
      ConditionContainer runtimePreconditions,
      EffectContainer effectContainer,
      Action.CostCallback<T> costCallback,
      Action.StartCallback<T> startCallback,
      Action.PerformCallback<T> performCallback,
      Action.FinishCallback<T> finishCallback
   ) {
      this.name = name;
      this.planTimePreconditions = planTimePreconditions;
      this.runtimePreconditions = runtimePreconditions;
      this.effects = effectContainer;
      this.costCallback = costCallback;
      this.startCallback = startCallback;
      this.performCallback = performCallback;
      this.finishCallback = finishCallback;
   }

   @Override
   public float getCost(T actor, ReadableWorldState worldState) {
      return this.costCallback.apply(actor, worldState);
   }

   @Override
   public Action.Signal perform(Action.Context<? extends T> context) {
      return this.performCallback.accept(context);
   }

   @Override
   public void onStart(Action.Context<? extends T> context) {
      this.startCallback.apply(context);
   }

   @Override
   public void onFinish(Action.Context<? extends T> context) {
      this.finishCallback.apply(context);
   }

   @Override
   public ConditionContainer getPreconditionContainer() {
      return this.planTimePreconditions.union(this.runtimePreconditions);
   }

   @Override
   public ConditionContainer getPlanTimePreconditionContainer() {
      return this.planTimePreconditions;
   }

   @Override
   public ConditionContainer getRuntimePreconditionContainer() {
      return this.runtimePreconditions;
   }

   @Override
   public EffectContainer getEffectContainer() {
      return this.effects;
   }

   @Override
   public String getName() {
      return this.name;
   }

   @Override
   public String toString() {
      return this.getName();
   }

   public abstract static class Builder<T, B extends BaseAction.Builder<T, B>> {
      protected final List<Condition<?>> planTimePreconditions = new ArrayList<>();
      protected final List<Condition<?>> runtimePreconditions = new ArrayList<>();
      protected final List<Effect<?>> effects = new ArrayList<>();
      protected Action.CostCallback<T> costCallback;
      protected Action.StartCallback<T> startCallback;
      protected Action.PerformCallback<T> performCallback;
      protected Action.FinishCallback<T> finishCallback;
      protected String name;

      protected Builder(String name) {
         this.name = name;
         this.costCallback = ($1, $2) -> 0.0F;
         this.startCallback = $ -> {};
         this.performCallback = $ -> Action.Signal.CONTINUE;
         this.finishCallback = $ -> {};
      }

      protected abstract B self();

      public <U> B addPrecondition(StateKey.Derived<? extends U> key, Expression<? super U> expression) {
         return this.addPrecondition(Condition.derived(key, expression));
      }

      public <U> B addPrecondition(StateKey.Sensed<? extends U> key, Expression<? super U> expression) {
         return this.addPrecondition(Condition.sensed(key, expression));
      }

      public B addPrecondition(Condition<?> condition) {
         this.planTimePreconditions.add(condition);
         this.runtimePreconditions.add(condition);
         return this.self();
      }

      public <U> B addPlanTimePrecondition(StateKey.Derived<? extends U> key, Expression<? super U> expression) {
         return this.addPlanTimePrecondition(Condition.derived(key, expression));
      }

      public <U> B addPlanTimePrecondition(StateKey.Sensed<? extends U> key, Expression<? super U> expression) {
         return this.addPlanTimePrecondition(Condition.sensed(key, expression));
      }

      public B addPlanTimePrecondition(Condition<?> condition) {
         this.planTimePreconditions.add(condition);
         return this.self();
      }

      public <U> B addRuntimePrecondition(StateKey.Derived<? extends U> key, Expression<? super U> expression) {
         return this.addRuntimePrecondition(Condition.derived(key, expression));
      }

      public <U> B addRuntimePrecondition(StateKey.Sensed<? extends U> key, Expression<? super U> expression) {
         return this.addRuntimePrecondition(Condition.sensed(key, expression));
      }

      public B addRuntimePrecondition(Condition<?> condition) {
         this.runtimePreconditions.add(condition);
         return this.self();
      }

      public <U> B addEffect(StateKey.Derived<U> key, UnaryOperator<U> consumer) {
         return this.addEffect(new Effect.Dynamic<>(key, consumer));
      }

      public <U> B addEffect(StateKey.Derived<U> key, U value) {
         return this.addEffect(new Effect.Value<>(key, value));
      }

      public B addEffect(Effect<?> effect) {
         this.effects.add(effect);
         return this.self();
      }

      public B withName(String name) {
         this.name = name;
         return this.self();
      }

      public B withCost(float cost) {
         return this.withCostCallback(($1, $2) -> cost);
      }

      public B withCostCallback(Action.CostCallback<T> costCallback) {
         this.costCallback = costCallback;
         return this.self();
      }

      public B withStartCallback(Action.StartCallback<T> startCallback) {
         this.startCallback = startCallback;
         return this.self();
      }

      public B withPerformCallback(Action.PerformCallback<T> performCallback) {
         this.performCallback = performCallback;
         return this.self();
      }

      public B withFinishCallback(Action.FinishCallback<T> finishCallback) {
         this.finishCallback = finishCallback;
         return this.self();
      }

      public B apply(UnaryOperator<B> unaryOperator) {
         return unaryOperator.apply(this.self());
      }

      public BaseAction<T> build() {
         if (this.effects.isEmpty()) {
            throw new IllegalStateException("Action must have at least one effect.");
         } else {
            return new BaseAction<>(
               this.name,
               ConditionContainer.of(Collections.unmodifiableList(this.planTimePreconditions)),
               ConditionContainer.of(Collections.unmodifiableList(this.runtimePreconditions)),
               EffectContainer.of(Collections.unmodifiableList(this.effects)),
               this.costCallback,
               this.startCallback,
               this.performCallback,
               this.finishCallback
            );
         }
      }
   }

   public static class ConcreteBuilder<T> extends BaseAction.Builder<T, BaseAction.ConcreteBuilder<T>> {
      protected ConcreteBuilder(String name) {
         super(name);
      }

      protected BaseAction.ConcreteBuilder<T> self() {
         return this;
      }
   }
}
