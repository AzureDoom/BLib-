package com.just.ai.goap.plan.scorer;

import com.just.ai.goap.plan.Plan;
import java.util.List;

public final class PlanScorers {
   private PlanScorers() {
   }

   public static <T> PlanScorer<T> costEfficiency() {
      return (plan, actor, worldState, allPlans) -> {
         float maxCost = 0.0F;

         for (Plan<T> otherPlan : allPlans) {
            maxCost = Math.max(maxCost, otherPlan.getInitialCost());
         }

         return maxCost == 0.0F ? 1.0F : clamp01(1.0F - plan.getInitialCost() / maxCost);
      };
   }

   public static <T> PlanScorer<T> goalDesirability(GoalDesirability<T> desirability) {
      return (plan, actor, worldState, allPlans) -> clamp01(desirability.getDesirability(plan.getGoal(), actor, worldState));
   }

   public static <T> PlanScorer<T> brevity() {
      return (plan, actor, worldState, allPlans) -> {
         int maxActions = 0;

         for (Plan<T> otherPlan : allPlans) {
            maxActions = Math.max(maxActions, otherPlan.getActions().size());
         }

         return maxActions <= 1 ? 1.0F : clamp01(1.0F - (float)(plan.getActions().size() - 1) / (maxActions - 1));
      };
   }

   @SafeVarargs
   public static <T> PlanScorer<T> weighted(PlanScorers.WeightedScorer<T>... weightedScorers) {
      List<PlanScorers.WeightedScorer<T>> scorers = List.of(weightedScorers);
      return (plan, actor, worldState, allPlans) -> {
         float totalWeight = 0.0F;
         float totalScore = 0.0F;

         for (PlanScorers.WeightedScorer<T> weightedScorer : scorers) {
            totalWeight += weightedScorer.weight();
            totalScore += weightedScorer.weight() * clamp01(weightedScorer.scorer().score(plan, actor, worldState, allPlans));
         }

         return totalWeight == 0.0F ? 0.0F : clamp01(totalScore / totalWeight);
      };
   }

   @SafeVarargs
   public static <T> PlanScorer<T> multiplicative(PlanScorer<T>... planScorers) {
      List<PlanScorer<T>> scorers = List.of(planScorers);
      return (plan, actor, worldState, allPlans) -> {
         float result = 1.0F;

         for (PlanScorer<T> scorer : scorers) {
            result *= clamp01(scorer.score(plan, actor, worldState, allPlans));
            if (result == 0.0F) {
               return 0.0F;
            }
         }

         return clamp01(result);
      };
   }

   private static float clamp01(float score) {
      return Math.clamp(score, 0.0F, 1.0F);
   }

   public record WeightedScorer<T>(PlanScorer<T> scorer, float weight) {
      public WeightedScorer(PlanScorer<T> scorer, float weight) {
         if (weight < 0.0F) {
            throw new IllegalArgumentException("weight must not be negative");
         } else {
            this.scorer = scorer;
            this.weight = weight;
         }
      }
   }
}
