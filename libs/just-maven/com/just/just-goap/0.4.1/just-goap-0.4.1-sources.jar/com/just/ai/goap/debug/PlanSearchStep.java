package com.just.ai.goap.debug;

import java.util.List;

public record PlanSearchStep(String condition, List<String> candidateActions, List<PlanSearchActionAttempt> attempts) {
   public PlanSearchStep(String condition, List<String> candidateActions, List<PlanSearchActionAttempt> attempts) {
      candidateActions = List.copyOf(candidateActions);
      attempts = List.copyOf(attempts);
      this.condition = condition;
      this.candidateActions = candidateActions;
      this.attempts = attempts;
   }
}
