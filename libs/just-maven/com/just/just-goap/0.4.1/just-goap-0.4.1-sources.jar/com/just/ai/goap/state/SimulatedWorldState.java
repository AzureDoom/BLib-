package com.just.ai.goap.state;

import com.just.ai.goap.StateKey;
import com.just.ai.goap.effect.Effect;
import com.just.ai.goap.effect.EffectContainer;
import java.util.HashMap;
import java.util.Map;
import org.jetbrains.annotations.Nullable;

public final class SimulatedWorldState implements WorldState {
   private final WorldState simulatedWorldState = WorldState.create();
   private final ReadableWorldState backingWorldState;

   public SimulatedWorldState(ReadableWorldState backingWorldState) {
      this.backingWorldState = backingWorldState;
   }

   @Nullable
   @Override
   public <V> V getOrNull(StateKey<V> key) {
      V value = this.simulatedWorldState.getOrNull(key);
      return value != null ? value : this.backingWorldState.getOrNull(key);
   }

   @Override
   public Map<StateKey<?>, Object> getMap() {
      HashMap<StateKey<?>, Object> merged = new HashMap<>();
      merged.putAll(this.backingWorldState.getMap());
      merged.putAll(this.simulatedWorldState.getMap());
      return merged;
   }

   @Override
   public <V> void set(StateKey<V> key, V value) {
      this.simulatedWorldState.set(key, value);
   }

   @Override
   public void setAll(Map<StateKey<?>, Object> map) {
      this.simulatedWorldState.setAll(map);
   }

   @Override
   public void apply(EffectContainer effectContainer) {
      for (Effect<?> effect : effectContainer.getEffects()) {
         effect.apply(this);
      }
   }

   @Override
   public void clear() {
      this.simulatedWorldState.clear();
   }

   public SimulatedWorldState copy() {
      SimulatedWorldState copy = new SimulatedWorldState(this.backingWorldState);
      copy.simulatedWorldState.getMap().putAll(this.simulatedWorldState.getMap());
      return copy;
   }
}
