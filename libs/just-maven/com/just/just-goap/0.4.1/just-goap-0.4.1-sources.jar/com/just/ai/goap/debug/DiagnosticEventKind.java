package com.just.ai.goap.debug;

public enum DiagnosticEventKind {
   REPLAN_TRIGGERED,
   REPLAN_SKIPPED,
   PLANS_CREATED,
   PLAN_ACCEPTED,
   PLAN_REJECTED,
   PLAN_REMOVED,
   ACTION_STARTED,
   ACTION_SKIPPED,
   ACTION_PERFORMED,
   ACTION_INVALID;
}
