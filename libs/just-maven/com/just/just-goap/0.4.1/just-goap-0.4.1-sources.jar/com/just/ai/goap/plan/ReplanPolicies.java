package com.just.ai.goap.plan;

import com.just.ai.goap.debug.DiagnosticDetailKeys;
import java.util.ArrayList;
import java.util.function.Function;
import java.util.function.Predicate;

public class ReplanPolicies {
   public static <T> ReplanPolicy<T> always() {
      return new ReplanPolicy<T>() {
         @Override
         public boolean shouldReplan(ReplanPolicy.Context<T> context) {
            return true;
         }

         @Override
         public ReplanDecision evaluate(ReplanPolicy.Context<T> context) {
            return ReplanDecision.triggered(ReplanReason.ALWAYS);
         }
      };
   }

   public static <T> ReplanPolicy<T> never() {
      return new ReplanPolicy<T>() {
         @Override
         public boolean shouldReplan(ReplanPolicy.Context<T> context) {
            return false;
         }

         @Override
         public ReplanDecision evaluate(ReplanPolicy.Context<T> context) {
            return ReplanDecision.skipped(ReplanReason.NEVER);
         }
      };
   }

   public static <T> ReplanPolicy<T> ifNoActivePlans() {
      return new ReplanPolicy<T>() {
         @Override
         public boolean shouldReplan(ReplanPolicy.Context<T> context) {
            return !context.agent().getPlanExecutor().hasActivePlans();
         }

         @Override
         public ReplanDecision evaluate(ReplanPolicy.Context<T> context) {
            return this.shouldReplan(context)
               ? ReplanDecision.triggered(ReplanReason.NO_ACTIVE_PLANS)
               : ReplanDecision.skipped(ReplanReason.ACTIVE_PLANS_PRESENT);
         }
      };
   }

   public static <T> ReplanPolicy<T> custom(final Predicate<ReplanPolicy.Context<T>> predicate) {
      return new ReplanPolicy<T>() {
         @Override
         public boolean shouldReplan(ReplanPolicy.Context<T> context) {
            return predicate.test(context);
         }
      };
   }

   public static <T> ReplanPolicy<T> custom(
      final Predicate<ReplanPolicy.Context<T>> predicate, final Function<ReplanPolicy.Context<T>, ReplanDecision> evaluator
   ) {
      return new ReplanPolicy<T>() {
         @Override
         public boolean shouldReplan(ReplanPolicy.Context<T> context) {
            return predicate.test(context);
         }

         @Override
         public ReplanDecision evaluate(ReplanPolicy.Context<T> context) {
            return evaluator.apply(context);
         }
      };
   }

   @SafeVarargs
   public static <T> ReplanPolicy<T> allOf(final ReplanPolicy<T>... replanPolicies) {
      return new ReplanPolicy<T>() {
         @Override
         public boolean shouldReplan(ReplanPolicy.Context<T> context) {
            for (ReplanPolicy<T> policy : replanPolicies) {
               if (!policy.shouldReplan(context)) {
                  return false;
               }
            }

            return true;
         }

         @Override
         public ReplanDecision evaluate(ReplanPolicy.Context<T> context) {
            ArrayList<ReplanDecision> childDecisions = new ArrayList<>(replanPolicies.length);

            for (ReplanPolicy<T> policy : replanPolicies) {
               ReplanDecision decision = policy.evaluate(context);
               childDecisions.add(decision);
               if (!decision.shouldReplan()) {
                  return ReplanDecision.skipped(
                     ReplanReason.ALL_POLICY_BLOCKED, DiagnosticDetailKeys.REPLAN_CHILD_DECISIONS.detail(new ReplanDecisions(childDecisions))
                  );
               }
            }

            return ReplanDecision.triggered(
               ReplanReason.ALL_POLICIES_MATCHED, DiagnosticDetailKeys.REPLAN_CHILD_DECISIONS.detail(new ReplanDecisions(childDecisions))
            );
         }
      };
   }

   @SafeVarargs
   public static <T> ReplanPolicy<T> anyOf(final ReplanPolicy<T>... replanPolicies) {
      return new ReplanPolicy<T>() {
         @Override
         public boolean shouldReplan(ReplanPolicy.Context<T> context) {
            for (ReplanPolicy<T> policy : replanPolicies) {
               if (policy.shouldReplan(context)) {
                  return true;
               }
            }

            return false;
         }

         @Override
         public ReplanDecision evaluate(ReplanPolicy.Context<T> context) {
            ArrayList<ReplanDecision> childDecisions = new ArrayList<>(replanPolicies.length);

            for (ReplanPolicy<T> policy : replanPolicies) {
               ReplanDecision decision = policy.evaluate(context);
               childDecisions.add(decision);
               if (decision.shouldReplan()) {
                  return ReplanDecision.triggered(
                     ReplanReason.ANY_POLICY_MATCHED, DiagnosticDetailKeys.REPLAN_CHILD_DECISIONS.detail(new ReplanDecisions(childDecisions))
                  );
               }
            }

            return ReplanDecision.skipped(
               ReplanReason.ANY_POLICIES_BLOCKED, DiagnosticDetailKeys.REPLAN_CHILD_DECISIONS.detail(new ReplanDecisions(childDecisions))
            );
         }
      };
   }

   private ReplanPolicies() {
      throw new UnsupportedOperationException();
   }
}
