package com.just.ai.goap.debug;

import com.just.ai.goap.action.Action;
import com.just.ai.goap.condition.Condition;
import com.just.ai.goap.condition.ConditionContainer;
import com.just.ai.goap.plan.Plan;
import com.just.ai.goap.plan.ReplanDecision;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

public final class AgentDiagnostics {
   private static final int DEFAULT_MAX_EVENTS = 128;
   private static final int DEFAULT_MAX_PLAN_SEARCHES = 32;
   private final ArrayDeque<PlanExecutionEvent> events;
   private final ArrayDeque<PlanSearchResult> planSearches;
   private final int maxEvents;
   private final int maxPlanSearches;
   private volatile boolean enabled;

   public AgentDiagnostics() {
      this(128, 32);
   }

   public AgentDiagnostics(int maxEvents, int maxPlanSearches) {
      if (maxEvents < 1) {
         throw new IllegalArgumentException("maxEvents must be at least 1");
      } else if (maxPlanSearches < 1) {
         throw new IllegalArgumentException("maxPlanSearches must be at least 1");
      } else {
         this.events = new ArrayDeque<>();
         this.planSearches = new ArrayDeque<>();
         this.maxEvents = maxEvents;
         this.maxPlanSearches = maxPlanSearches;
         this.enabled = false;
      }
   }

   public synchronized void clear() {
      this.events.clear();
      this.planSearches.clear();
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void setEnabled(boolean enabled) {
      this.enabled = enabled;
   }

   public synchronized AgentDiagnosticsSnapshot snapshot(long tick) {
      return new AgentDiagnosticsSnapshot(tick, List.copyOf(this.planSearches), List.copyOf(this.events));
   }

   public synchronized void recordPlanSearch(PlanSearchResult result) {
      if (this.enabled) {
         appendBounded(this.planSearches, result, this.maxPlanSearches);
      }
   }

   public void recordReplanDecision(long tick, ReplanDecision decision) {
      if (this.enabled) {
         ArrayList<DiagnosticDetail<?>> details = new ArrayList<>();
         details.add(DiagnosticDetailKeys.SHOULD_REPLAN.detail(decision.shouldReplan()));
         details.add(DiagnosticDetailKeys.REPLAN_REASON.detail(decision.reason()));
         details.addAll(decision.details());
         this.recordEvent(
            tick, decision.shouldReplan() ? DiagnosticEventKind.REPLAN_TRIGGERED : DiagnosticEventKind.REPLAN_SKIPPED, PlanSummary.none(), -1, "", details
         );
      }
   }

   public void recordPlansCreated(long tick, List<? extends Plan<?>> plans) {
      if (this.enabled) {
         this.recordEvent(
            tick,
            DiagnosticEventKind.PLANS_CREATED,
            PlanSummary.none(),
            -1,
            "",
            details(DiagnosticDetailKeys.PLAN_COUNT.detail(plans.size()), DiagnosticDetailKeys.PLAN_SUMMARIES.detail(planSummaries(plans)))
         );
      }
   }

   public void recordPlanEvent(long tick, DiagnosticEventKind kind, Plan<?> plan, List<DiagnosticDetail<?>> details) {
      if (this.enabled) {
         this.recordEvent(tick, kind, summarize(plan), plan.getCurrentActionIndex(), currentActionName(plan), details);
      }
   }

   public void recordActionEvent(long tick, DiagnosticEventKind kind, Plan<?> plan, int actionIndex, String actionName, List<DiagnosticDetail<?>> details) {
      if (this.enabled) {
         this.recordEvent(tick, kind, summarize(plan), actionIndex, actionName, details);
      }
   }

   private synchronized void recordEvent(
      long tick, DiagnosticEventKind kind, PlanSummary plan, int actionIndex, String actionName, List<DiagnosticDetail<?>> details
   ) {
      if (this.enabled) {
         appendBounded(this.events, new PlanExecutionEvent(tick, kind, plan, actionIndex, actionName, details), this.maxEvents);
      }
   }

   private static <T> void appendBounded(ArrayDeque<T> deque, T value, int maxSize) {
      while (deque.size() >= maxSize) {
         deque.removeFirst();
      }

      deque.addLast(value);
   }

   public static PlanSummary summarize(Plan<?> plan) {
      return new PlanSummary(plan.getId(), plan.getGoal().getName(), actionNames(plan.getActions()), plan.getInitialCost());
   }

   public static List<String> actionNames(List<? extends Action<?>> actions) {
      ArrayList<String> names = new ArrayList<>(actions.size());

      for (Action<?> action : actions) {
         names.add(action.getName());
      }

      return names;
   }

   public static List<String> conditionSummaries(ConditionContainer container) {
      ArrayList<String> summaries = new ArrayList<>();

      for (Condition<?> condition : container.getConditions()) {
         summaries.add(condition.toString());
      }

      return summaries;
   }

   @SafeVarargs
   public static List<DiagnosticDetail<?>> details(DiagnosticDetail<?>... details) {
      return List.of(details);
   }

   private static String currentActionName(Plan<?> plan) {
      int index = plan.getCurrentActionIndex();
      List<? extends Action<?>> actions = plan.getActions();
      return index >= 0 && index < actions.size() ? actions.get(index).getName() : "";
   }

   private static PlanSummaries planSummaries(List<? extends Plan<?>> plans) {
      ArrayList<PlanSummary> summaries = new ArrayList<>(plans.size());

      for (Plan<?> plan : plans) {
         summaries.add(summarize(plan));
      }

      return new PlanSummaries(summaries);
   }
}
