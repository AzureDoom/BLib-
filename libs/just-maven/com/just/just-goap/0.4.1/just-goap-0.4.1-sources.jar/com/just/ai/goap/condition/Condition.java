package com.just.ai.goap.condition;

import com.just.ai.goap.Satisfiable;
import com.just.ai.goap.StateKey;
import com.just.ai.goap.condition.expression.Expression;
import com.just.ai.goap.effect.EffectContainer;
import com.just.ai.goap.state.ReadableWorldState;

public abstract sealed class Condition<T> implements Satisfiable permits Condition.Derived, Condition.Sensed {
   private final StateKey<T> key;
   private final Expression<? super T> expression;

   public static <T> Condition.Derived<T> derived(StateKey.Derived<T> key, Expression<? super T> expression) {
      return new Condition.Derived<>(key, expression);
   }

   public static <T> Condition.Sensed<T> sensed(StateKey.Sensed<T> key, Expression<? super T> expression) {
      return new Condition.Sensed<>(key, expression);
   }

   protected Condition(StateKey<T> key, Expression<? super T> expression) {
      this.key = key;
      this.expression = expression;
   }

   @Override
   public boolean satisfiedBy(EffectContainer effectContainer) {
      return this.satisfiedBy(effectContainer.toWorldState());
   }

   @Override
   public boolean satisfiedBy(ReadableWorldState worldState) {
      T value = worldState.getOrNull(this.key);
      return value != null && this.expression.evaluate(value);
   }

   public StateKey<T> key() {
      return this.key;
   }

   @Override
   public String toString() {
      return this.key.id() + " " + this.expression;
   }

   public static final class Derived<T> extends Condition<T> {
      private Derived(StateKey.Derived<T> key, Expression<? super T> expression) {
         super(key, expression);
      }
   }

   public static final class Sensed<T> extends Condition<T> {
      private Sensed(StateKey.Sensed<T> key, Expression<? super T> expression) {
         super(key, expression);
      }
   }
}
