package com.just.ai.goap.debug;

public enum PlanSearchStatus {
   GOAL_BLOCKED,
   ALREADY_SATISFIED,
   SOLVED,
   NO_PLAN;
}
