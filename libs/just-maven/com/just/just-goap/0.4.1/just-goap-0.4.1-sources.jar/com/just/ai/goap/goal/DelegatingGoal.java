package com.just.ai.goap.goal;

import com.just.ai.goap.StateKey;
import com.just.ai.goap.condition.Condition;
import com.just.ai.goap.condition.ConditionContainer;
import com.just.ai.goap.condition.expression.Expression;
import java.util.function.UnaryOperator;

public abstract class DelegatingGoal implements Goal {
   private final Goal delegate;

   protected DelegatingGoal(Goal delegate) {
      this.delegate = delegate;
   }

   public Goal getDelegate() {
      return this.delegate;
   }

   @Override
   public ConditionContainer getDesiredConditions() {
      return this.delegate.getDesiredConditions();
   }

   @Override
   public String getName() {
      return this.delegate.getName();
   }

   @Override
   public ConditionContainer getPreconditions() {
      return this.delegate.getPreconditions();
   }

   @Override
   public String toString() {
      return this.delegate.toString();
   }

   public abstract static class Builder<B extends DelegatingGoal.Builder<B>> {
      protected final BaseGoal.ConcreteBuilder baseBuilder;

      protected Builder(String name) {
         this.baseBuilder = BaseGoal.builder(name);
      }

      protected abstract B self();

      protected abstract DelegatingGoal build(Goal var1);

      public <U> B addDesiredCondition(StateKey.Derived<? extends U> key, Expression<? super U> expression) {
         this.baseBuilder.addDesiredCondition(key, expression);
         return this.self();
      }

      public <U> B addDesiredCondition(Condition.Derived<U> condition) {
         this.baseBuilder.addDesiredCondition(condition);
         return this.self();
      }

      public <U> B addPrecondition(StateKey.Sensed<? extends U> key, Expression<? super U> expression) {
         this.baseBuilder.addPrecondition(key, expression);
         return this.self();
      }

      public <U> B addPrecondition(Condition.Sensed<U> condition) {
         this.baseBuilder.addPrecondition(condition);
         return this.self();
      }

      public B withName(String name) {
         this.baseBuilder.withName(name);
         return this.self();
      }

      public B apply(UnaryOperator<B> unaryOperator) {
         return unaryOperator.apply(this.self());
      }

      public DelegatingGoal build() {
         BaseGoal baseGoal = this.baseBuilder.build();
         return this.build(baseGoal);
      }
   }
}
