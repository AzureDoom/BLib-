package com.just.ai.goap.state;

import com.just.ai.goap.StateKey;
import com.just.ai.goap.effect.Effect;
import com.just.ai.goap.effect.EffectContainer;
import java.util.HashMap;
import java.util.Map;
import org.jetbrains.annotations.Nullable;

public interface WorldState extends ReadableWorldState, WritableWorldState {
   static WorldState create() {
      return create(new HashMap<>());
   }

   static WorldState create(final Map<StateKey<?>, Object> stateMap) {
      return new WorldState() {
         @Nullable
         @Override
         public <T> T getOrNull(StateKey<T> key) {
            return (T)stateMap.get(key);
         }

         @Override
         public Map<StateKey<?>, Object> getMap() {
            return stateMap;
         }

         @Override
         public <T> void set(StateKey<T> key, T value) {
            stateMap.put(key, value);
         }

         @Override
         public void setAll(Map<StateKey<?>, Object> map) {
            stateMap.putAll(map);
         }

         @Override
         public void apply(EffectContainer effectContainer) {
            for (Effect<?> effect : effectContainer.getEffects()) {
               effect.apply(this);
            }
         }

         @Override
         public void clear() {
            stateMap.clear();
         }
      };
   }
}
