package com.just.ai.goap.state;

import com.just.ai.goap.Satisfiable;
import com.just.ai.goap.Satisfier;
import com.just.ai.goap.StateKey;
import com.just.ai.goap.condition.ConditionContainer;
import com.just.ai.goap.effect.EffectContainer;
import com.just.core.functional.option.Option;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;
import org.jetbrains.annotations.Nullable;

public interface ReadableWorldState extends Satisfiable, Satisfier {
   @Nullable
   <T> T getOrNull(StateKey<T> var1);

   Map<StateKey<?>, Object> getMap();

   @Override
   default boolean satisfiedBy(ReadableWorldState worldState) {
      for (Entry<StateKey<?>, Object> entry : this.getMap().entrySet()) {
         Object otherValue = worldState.getOrNull(entry.getKey());
         if (!entry.getValue().equals(otherValue)) {
            return false;
         }
      }

      return true;
   }

   @Override
   default boolean satisfies(EffectContainer effectContainer) {
      return effectContainer.toWorldState().satisfiedBy(this);
   }

   @Override
   default boolean satisfies(ConditionContainer conditionContainer) {
      return conditionContainer.satisfiedBy(this);
   }

   default boolean has(StateKey<?> key) {
      Object value = this.getOrNull(key);
      return value != null;
   }

   default <T> T getOrDefault(StateKey<T> key, T defaultValue) {
      T value = this.getOrNull(key);
      return value == null ? defaultValue : value;
   }

   default <T> T getOrThrow(StateKey<T> key) {
      return Objects.requireNonNull(this.getOrNull(key));
   }

   default <T> Option<T> get(StateKey<T> key) {
      return Option.ofNullable(this.getOrNull(key));
   }
}
