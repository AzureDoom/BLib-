package com.just.ai.goap.state;

import com.just.ai.goap.StateKey;
import com.just.core.functional.option.Option;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class Blackboard {
   private final Map<StateKey<?>, Object> stateMap = new HashMap<>();

   public Map<StateKey<?>, Object> getStateMap() {
      return Collections.unmodifiableMap(this.stateMap);
   }

   public <T> T getOrNull(StateKey<T> key) {
      return this.getOrDefault(key, null);
   }

   public <T> T getOrDefault(StateKey<T> key, T defaultValue) {
      return (T)this.stateMap.getOrDefault(key, defaultValue);
   }

   public <T> T getOrThrow(StateKey<T> key) {
      return Objects.requireNonNull(this.getOrNull(key));
   }

   public <T> Option<T> get(StateKey<T> key) {
      return Option.ofNullable(this.getOrNull(key));
   }

   public <T> void set(StateKey<T> key, T value) {
      this.stateMap.put(key, value);
   }

   public void clear() {
      this.stateMap.clear();
   }

   public static enum Scope {
      ACTION,
      AGENT,
      GRAPH,
      PLAN;
   }
}
