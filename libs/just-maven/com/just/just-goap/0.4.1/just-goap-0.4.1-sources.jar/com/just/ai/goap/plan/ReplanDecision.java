package com.just.ai.goap.plan;

import com.just.ai.goap.debug.DiagnosticDetail;
import java.util.List;

public record ReplanDecision(boolean shouldReplan, ReplanReason reason, List<DiagnosticDetail<?>> details) {
   public ReplanDecision(boolean shouldReplan, ReplanReason reason, List<DiagnosticDetail<?>> details) {
      details = List.copyOf(details);
      this.shouldReplan = shouldReplan;
      this.reason = reason;
      this.details = details;
   }

   @SafeVarargs
   public static ReplanDecision skipped(ReplanReason reason, DiagnosticDetail<?>... details) {
      return new ReplanDecision(false, reason, List.of(details));
   }

   @SafeVarargs
   public static ReplanDecision triggered(ReplanReason reason, DiagnosticDetail<?>... details) {
      return new ReplanDecision(true, reason, List.of(details));
   }
}
