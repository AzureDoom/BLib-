package com.just.ai.goap.plan;

import java.util.List;

public record ReplanDecisions(List<ReplanDecision> decisions) {
   public ReplanDecisions(List<ReplanDecision> decisions) {
      decisions = List.copyOf(decisions);
      this.decisions = decisions;
   }
}
