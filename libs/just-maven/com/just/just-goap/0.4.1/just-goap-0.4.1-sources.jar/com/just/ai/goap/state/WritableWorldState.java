package com.just.ai.goap.state;

import com.just.ai.goap.StateKey;
import com.just.ai.goap.effect.EffectContainer;
import java.util.Map;

public interface WritableWorldState {
   <T> void set(StateKey<T> var1, T var2);

   void setAll(Map<StateKey<?>, Object> var1);

   void apply(EffectContainer var1);

   void clear();
}
