package com.just.ai.goap.plan.executor;

import com.just.ai.goap.Agent;
import com.just.ai.goap.plan.Plan;
import com.just.ai.goap.state.ReadableWorldState;
import java.util.List;

public interface PlanExecutor<T> {
   PlanExecutor.Result execute(PlanExecutor.ExecutionContext<T> var1);

   void supplyPlans(List<Plan<T>> var1, T var2, ReadableWorldState var3);

   default void supplyPlans(PlanExecutor.SupplyContext<T> context) {
      this.supplyPlans(context.plans(), context.actor(), context.worldState());
   }

   boolean hasActivePlans();

   void abandonAllPlans();

   public record ExecutionContext<T>(Agent<T> agent, T actor, ReadableWorldState currentWorldState, ReadableWorldState previousWorldState) {
   }

   public static enum Result {
      IN_PROGRESS,
      IDLE,
      NO_PLANS;
   }

   public record SupplyContext<T>(Agent<T> agent, List<Plan<T>> plans, T actor, ReadableWorldState worldState) {
      public SupplyContext(Agent<T> agent, List<Plan<T>> plans, T actor, ReadableWorldState worldState) {
         plans = List.copyOf(plans);
         this.agent = agent;
         this.plans = plans;
         this.actor = actor;
         this.worldState = worldState;
      }
   }
}
