package com.just.ai.goap.plan;

import com.just.ai.goap.action.Action;
import java.util.List;

public final class PlanComparator {
   private PlanComparator() {
   }

   public static <T> boolean hasSameGoal(Plan<T> planA, Plan<T> planB) {
      if (planA == planB) {
         return true;
      } else {
         return planA != null && planB != null ? planA.getGoal().equals(planB.getGoal()) : false;
      }
   }

   public static <T> boolean hasSameGoalAndActions(Plan<T> planA, Plan<T> planB) {
      if (planA == planB) {
         return true;
      } else if (planA != null && planB != null) {
         return !planA.getGoal().equals(planB.getGoal()) ? false : hasSameActions(planA.getActions(), planB.getActions());
      } else {
         return false;
      }
   }

   public static <T> boolean hasSameActions(List<Action<? super T>> actionsA, List<Action<? super T>> actionsB) {
      if (actionsA == actionsB) {
         return true;
      } else if (actionsA.size() != actionsB.size()) {
         return false;
      } else {
         for (int i = 0; i < actionsA.size(); i++) {
            if (actionsA.get(i) != actionsB.get(i)) {
               return false;
            }
         }

         return true;
      }
   }
}
