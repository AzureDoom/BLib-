package com.just.ai.goap.debug;

import java.util.List;

public record PlanSummaries(List<PlanSummary> plans) {
   public PlanSummaries(List<PlanSummary> plans) {
      plans = List.copyOf(plans);
      this.plans = plans;
   }
}
