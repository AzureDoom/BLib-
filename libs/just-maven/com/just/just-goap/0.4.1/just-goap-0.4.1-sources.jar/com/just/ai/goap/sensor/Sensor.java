package com.just.ai.goap.sensor;

import com.just.ai.goap.StateKey;
import com.just.ai.goap.state.ReadableWorldState;
import java.util.Set;

public interface Sensor<T> {
   Set<StateKey.Sensed<?>> outputKeys();

   <V> V apply(StateKey<V> var1, T var2, ReadableWorldState var3);

   /**
    * How many agent ticks a value from this sensor stays valid once sensed.
    * <p>
    * The default of 1 is the original behaviour: every value is discarded at the start of the next tick and sensed
    * again on first read. A larger value keeps the reading for that many ticks, so an expensive sensor (an entity
    * scan, a raycast) runs once per window instead of once per tick. Opt in with {@link Sensors#every}.
    * </p>
    * <p>
    * Added in 0.4.1. Only honoured while the agent's sensing optimisations are enabled; with them off every sensor
    * behaves as if this returned 1.
    * </p>
    */
   default int refreshTicks() {
      return 1;
   }

   public interface Mono<T, O> extends Sensor<T> {
      StateKey.Sensed<O> key();

      @Override
      default Set<StateKey.Sensed<?>> outputKeys() {
         return Set.of(this.key());
      }
   }

   public interface Multi<T> extends Sensor<T> {
   }
}
