package com.just.ai.goap.condition;

import com.just.ai.goap.Satisfiable;
import com.just.ai.goap.state.ReadableWorldState;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class ConditionContainer implements Satisfiable {
   private final List<Condition<?>> conditions;

   public static ConditionContainer of(Condition<?>... conditions) {
      return of(List.of(conditions));
   }

   public static ConditionContainer of(List<Condition<?>> conditions) {
      return new ConditionContainer(conditions);
   }

   private ConditionContainer(List<Condition<?>> conditions) {
      this.conditions = conditions;
   }

   @Override
   public boolean satisfiedBy(ReadableWorldState worldState) {
      for (Condition<?> condition : this.conditions) {
         if (!condition.satisfiedBy(worldState)) {
            return false;
         }
      }

      return true;
   }

   public ConditionContainer filterUnsatisfied(ReadableWorldState worldState) {
      ArrayList<Condition<?>> unsatisfied = new ArrayList<>();

      for (Condition<?> condition : this.conditions) {
         if (!condition.satisfiedBy(worldState)) {
            unsatisfied.add(condition);
         }
      }

      return new ConditionContainer(unsatisfied);
   }

   public ConditionContainer without(Condition<?>... toRemove) {
      Set<Condition<?>> removeSet = Set.of(toRemove);
      ArrayList<Condition<?>> remaining = new ArrayList<>();

      for (Condition<?> condition : this.conditions) {
         if (!removeSet.contains(condition)) {
            remaining.add(condition);
         }
      }

      return new ConditionContainer(remaining);
   }

   public ConditionContainer union(ConditionContainer other) {
      LinkedHashSet<Condition<?>> combined = new LinkedHashSet<>(this.conditions);
      combined.addAll(other.conditions);
      return new ConditionContainer(new ArrayList<>(combined));
   }

   public boolean isEmpty() {
      return this.conditions.isEmpty();
   }

   public List<Condition<?>> getConditions() {
      return this.conditions;
   }
}
