package com.just.ai.goap;

import com.just.ai.goap.action.Action;
import com.just.ai.goap.condition.Condition;
import com.just.ai.goap.condition.ConditionContainer;
import com.just.ai.goap.debug.PlanSearchCollector;
import com.just.ai.goap.graph.Graph;
import com.just.ai.goap.state.ReadableWorldState;
import com.just.ai.goap.state.SimulatedWorldState;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Set;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class AOStar {
   private static final Logger LOGGER = LoggerFactory.getLogger(AOStar.class);
   private static final Comparator<AOStar.AOStarNode<?>> F_COST_COMPARATOR = Comparator.comparingDouble(node -> node.fCost);

   @Nullable
   public static <T> List<AOStar.ActionWithCost<? super T>> solve(
      Graph<T> graph, ConditionContainer desiredConditions, ReadableWorldState currentWorldState, T actor
   ) {
      return solve(graph, desiredConditions, currentWorldState, actor, null);
   }

   @Nullable
   public static <T> List<AOStar.ActionWithCost<? super T>> solve(
      Graph<T> graph, ConditionContainer desiredConditions, ReadableWorldState currentWorldState, T actor, @Nullable PlanSearchCollector collector
   ) {
      PriorityQueue<AOStar.AOStarNode<T>> open = new PriorityQueue<>(F_COST_COMPARATOR);
      ConditionContainer rootUnsatisfied = desiredConditions.filterUnsatisfied(currentWorldState);
      SimulatedWorldState rootState = new SimulatedWorldState(currentWorldState);
      LOGGER.trace("Start state: {}", currentWorldState);
      LOGGER.trace("Root unsatisfied conditions: {}", rootUnsatisfied.getConditions());
      if (collector != null) {
         collector.started(rootUnsatisfied);
      }

      open.add(new AOStar.AOStarNode<>(rootUnsatisfied, new ArrayList<>(), rootState, 0.0F, heuristic(rootUnsatisfied, graph, actor, currentWorldState)));

      while (!open.isEmpty()) {
         AOStar.AOStarNode<T> node = open.poll();
         LOGGER.trace("\n--- Expanding node ---");
         LOGGER.trace("Plan so far: {}", node.planSoFar);
         LOGGER.trace("Unsatisfied conditions: {}", node.unsatisfiedConditions.getConditions());
         // 0.4.1: guarded - the varargs array and three float boxes were allocated on every expansion even with
         // trace logging off.
         if (LOGGER.isTraceEnabled()) {
            LOGGER.trace("g={} h={} f={}", new Object[]{node.gCost, node.hCost, node.fCost});
         }
         if (node.unsatisfiedConditions.isEmpty()) {
            LOGGER.trace("Goal reached! Returning plan.");
            List<AOStar.ActionWithCost<? super T>> result = node.planSoFar.reversed();
            if (collector != null) {
               collector.solved(result);
            }

            return result;
         }

         for (Condition<?> condition : node.unsatisfiedConditions.getConditions()) {
            LOGGER.trace("Expanding condition: {}", condition);
            Set<Action<? super T>> satisfyingActions = graph.getActionsThatSatisfy(condition);
            LOGGER.trace("Candidate actions: {}", satisfyingActions);
            if (collector != null) {
               collector.expanded(condition, satisfyingActions.stream().toList());
            }

            for (Action<? super T> action : satisfyingActions) {
               LOGGER.trace(" Trying action: {}", action);
               SimulatedWorldState newState = node.simulatedState.copy();
               newState.apply(action.getEffectContainer());
               LOGGER.trace("  Applied effects, new state: {}", newState);
               ConditionContainer unmetPreconditions = action.getPreconditionContainer().filterUnsatisfied(currentWorldState);
               ConditionContainer remaining = node.unsatisfiedConditions.without(condition).filterUnsatisfied(newState);
               ConditionContainer newUnsatisfied = remaining.union(unmetPreconditions);
               LOGGER.trace("  New unsatisfied after action: {}", newUnsatisfied.getConditions());
               float actionCost = action.getCost(actor, node.simulatedState);
               ArrayList<AOStar.ActionWithCost<? super T>> newPlan = new ArrayList<>(node.planSoFar);
               newPlan.add(new AOStar.ActionWithCost<>(action, actionCost));
               float g = node.gCost + actionCost;
               float h = heuristic(newUnsatisfied, graph, actor, node.simulatedState);
               // 0.4.1: guarded for the same reason as the node trace above.
               if (LOGGER.isTraceEnabled()) {
                  LOGGER.trace("  Action cost={} → g={} h={} f={}", new Object[]{actionCost, g, h, g + h});
               }
               if (collector != null) {
                  collector.triedAction(action, newUnsatisfied, actionCost, h);
               }

               open.add(new AOStar.AOStarNode<>(newUnsatisfied, newPlan, newState, g, h));
            }
         }
      }

      LOGGER.trace("No plan found.");
      if (collector != null) {
         collector.failed();
      }

      return null;
   }

   private static <T> float heuristic(ConditionContainer unsatisfied, Graph<T> graph, T actor, ReadableWorldState worldState) {
      float h = 0.0F;

      for (Condition<?> condition : unsatisfied.getConditions()) {
         Set<Action<? super T>> candidates = graph.getActionsThatSatisfy(condition);
         if (candidates.isEmpty()) {
            LOGGER.trace(" Heuristic: condition {} has no satisfiers → returning ∞", condition);
            return Float.MAX_VALUE;
         }

         float minCost = Float.MAX_VALUE;

         for (Action<? super T> action : candidates) {
            float cost = action.getCost(actor, worldState);
            if (cost < minCost) {
               minCost = cost;
            }
         }

         h += minCost;
      }

      return h;
   }

   record AOStarNode<T>(
      ConditionContainer unsatisfiedConditions,
      List<AOStar.ActionWithCost<? super T>> planSoFar,
      SimulatedWorldState simulatedState,
      float gCost,
      float hCost,
      float fCost
   ) {
      AOStarNode(
         ConditionContainer unsatisfiedConditions,
         List<AOStar.ActionWithCost<? super T>> planSoFar,
         SimulatedWorldState simulatedState,
         float gCost,
         float hCost
      ) {
         this(unsatisfiedConditions, planSoFar, simulatedState, gCost, hCost, gCost + hCost);
      }
   }

   public record ActionWithCost<T>(Action<? super T> action, float cost) {
   }
}
