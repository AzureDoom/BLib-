package com.just.ai.goap.sensor;

import com.just.ai.goap.StateKey;
import com.just.ai.goap.state.ReadableWorldState;
import com.just.core.functional.function.Function2;

public final class LazyCompose<T, O1> implements Sensor.Mono<T, O1> {
   private final StateKey.Sensed<O1> outputKeyA;
   private final Function2<? super T, ? super ReadableWorldState, ? extends java.util.Map<StateKey<?>, ?>> extractor;

   LazyCompose(StateKey.Sensed<O1> outputKeyA, Function2<? super T, ? super ReadableWorldState, ? extends java.util.Map<StateKey<?>, ?>> extractor) {
      this.outputKeyA = outputKeyA;
      this.extractor = extractor;
   }

   @Override
   public StateKey.Sensed<O1> key() {
      return this.outputKeyA;
   }

   @Override
   public <V> V apply(StateKey<V> key, T actor, ReadableWorldState worldState) {
      return (V)((java.util.Map)this.extractor.apply(actor, worldState)).get(key);
   }
}
