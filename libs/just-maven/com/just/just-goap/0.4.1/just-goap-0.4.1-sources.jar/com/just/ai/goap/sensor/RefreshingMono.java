package com.just.ai.goap.sensor;

import com.just.ai.goap.StateKey;
import com.just.ai.goap.state.ReadableWorldState;

/**
 * A {@link Sensor.Mono} whose values are held for a fixed number of ticks. Created by {@link Sensors#every}.
 * <p>
 * Added in 0.4.1. It only carries the window - sensing is delegated untouched, and the holding itself is done by
 * {@link com.just.ai.goap.state.SensingWorldState}.
 * </p>
 */
final class RefreshingMono<T, O> implements Sensor.Mono<T, O> {
   private final int refreshTicks;
   private final Sensor.Mono<T, O> delegate;

   RefreshingMono(int refreshTicks, Sensor.Mono<T, O> delegate) {
      this.refreshTicks = refreshTicks;
      this.delegate = delegate;
   }

   @Override
   public StateKey.Sensed<O> key() {
      return this.delegate.key();
   }

   @Override
   public <V> V apply(StateKey<V> key, T actor, ReadableWorldState worldState) {
      return this.delegate.apply(key, actor, worldState);
   }

   @Override
   public int refreshTicks() {
      return this.refreshTicks;
   }

   @Override
   public String toString() {
      return "every(" + this.refreshTicks + ", " + this.delegate + ")";
   }
}
