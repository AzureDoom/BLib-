package com.just.ai.goap.sensor;

import com.just.ai.goap.StateKey;
import com.just.ai.goap.state.ReadableWorldState;
import com.just.core.functional.function.Function;
import com.just.core.functional.function.Function2;
import com.just.core.functional.function.Function3;
import com.just.core.functional.function.Function4;
import com.just.core.functional.tuple.Tuple2;
import com.just.core.functional.tuple.Tuple3;

public class Sensors {
   /**
    * Keeps each value {@code sensor} produces for {@code ticks} agent ticks instead of re-sensing it every tick.
    * <p>
    * Use it for sensors that are expensive and change slowly - entity scans, raycasts, block searches. Do NOT use it
    * for a value an action waits on to finish (its effect) or a replan trigger compares tick-to-tick (health, fire):
    * a held value delays that reaction by up to {@code ticks - 1} ticks.
    * </p>
    * <p>
    * ⚠ The window is counted in AGENT UPDATES, not game ticks. A host that skips updates (BLib skips most updates of
    * an agent with no plan) holds values for longer in game time than {@code ticks} suggests.
    * </p>
    * <p>
    * Added in 0.4.1. {@code every(1, sensor)} behaves exactly like {@code sensor}.
    * </p>
    */
   public static <T, O> Sensor.Mono<T, O> every(int ticks, Sensor.Mono<T, O> sensor) {
      return new RefreshingMono<>(checkTicks(ticks), sensor);
   }

   /**
    * {@link #every(int, Sensor.Mono)} for a sensor with several output keys. Every key it feeds shares the window.
    */
   public static <T> Sensor.Multi<T> every(int ticks, Sensor.Multi<T> sensor) {
      return new RefreshingMulti<>(checkTicks(ticks), sensor);
   }

   private static int checkTicks(int ticks) {
      if (ticks < 1) {
         throw new IllegalArgumentException("A sensor refresh window must be at least 1 tick, got " + ticks);
      }

      return ticks;
   }

   public static <T, I1, O1> Compose<T, I1, O1> compose(
      StateKey.Sensed<I1> sourceKey, StateKey.Sensed<O1> key, Function2<? super T, ? super I1, ? extends O1> extractor
   ) {
      return new Compose<>(sourceKey, key, extractor);
   }

   public static <T, I1, I2, O1> Compose2<T, I1, I2, O1> compose(
      StateKey.Sensed<I1> sourceKeyA,
      StateKey.Sensed<I2> sourceKeyB,
      StateKey.Sensed<O1> key,
      Function3<? super T, ? super I1, ? super I2, ? extends O1> extractor
   ) {
      return new Compose2<>(sourceKeyA, sourceKeyB, key, extractor);
   }

   public static <T, I1, I2, I3, O1> Compose3<T, I1, I2, I3, O1> compose(
      StateKey.Sensed<I1> sourceKeyA,
      StateKey.Sensed<I2> sourceKeyB,
      StateKey.Sensed<I3> sourceKeyC,
      StateKey.Sensed<O1> key,
      Function4<? super T, ? super I1, ? super I2, ? super I3, ? extends O1> extractor
   ) {
      return new Compose3<>(sourceKeyA, sourceKeyB, sourceKeyC, key, extractor);
   }

   public static <T, O1, O2> Decompose2<T, O1, O2> decompose(
      StateKey.Sensed<O1> outputKeyA, StateKey.Sensed<O2> outputKeyB, Function<? super T, ? extends Tuple2<O1, O2>> extractor
   ) {
      return new Decompose2<>(outputKeyA, outputKeyB, actor -> {
         Tuple2<O1, O2> tuple = (Tuple2<O1, O2>)extractor.apply(actor);
         return java.util.Map.of(outputKeyA, tuple.v1(), (StateKey.Sensed<O1>)outputKeyB, tuple.v2());
      });
   }

   public static <T, O1, O2, O3> Decompose3<T, O1, O2, O3> decompose(
      StateKey.Sensed<O1> outputKeyA,
      StateKey.Sensed<O2> outputKeyB,
      StateKey.Sensed<O3> outputKeyC,
      Function<? super T, ? extends Tuple3<O1, O2, O3>> extractor
   ) {
      return new Decompose3<>(outputKeyA, outputKeyB, outputKeyC, actor -> {
         Tuple3<O1, O2, O3> tuple = (Tuple3<O1, O2, O3>)extractor.apply(actor);
         return java.util.Map.of(outputKeyA, tuple.v1(), (StateKey.Sensed<O1>)outputKeyB, tuple.v2(), (StateKey.Sensed<O1>)outputKeyC, tuple.v3());
      });
   }

   public static <T, O1> LazyCompose<T, O1> lazyCompose(
      StateKey.Sensed<O1> outputKeyA, Function2<? super T, ? super ReadableWorldState, ? extends O1> extractor
   ) {
      return new LazyCompose<>(outputKeyA, (actor, worldState) -> {
         O1 value = (O1)extractor.apply(actor, worldState);
         return java.util.Map.of(outputKeyA, value);
      });
   }

   public static <T, O1, O2> LazyDecompose2<T, O1, O2> lazyDecompose(
      StateKey.Sensed<O1> outputKeyA, StateKey.Sensed<O2> outputKeyB, Function2<? super T, ? super ReadableWorldState, ? extends Tuple2<O1, O2>> extractor
   ) {
      return new LazyDecompose2<>(outputKeyA, outputKeyB, (actor, worldState) -> {
         Tuple2<O1, O2> tuple = (Tuple2<O1, O2>)extractor.apply(actor, worldState);
         return java.util.Map.of(outputKeyA, tuple.v1(), (StateKey.Sensed<O1>)outputKeyB, tuple.v2());
      });
   }

   public static <T, O1> Map<T, O1> map(StateKey.Sensed<O1> key, Function<? super T, ? extends O1> extractor) {
      return new Map<>(key, extractor);
   }

   public static <T, I1, O1, O2> Map1To2<T, I1, O1, O2> multiMap(
      StateKey.Sensed<I1> sourceKeyA,
      StateKey.Sensed<O1> outputKeyA,
      StateKey.Sensed<O2> outputKeyB,
      Function2<? super T, ? super I1, ? extends Tuple2<O1, O2>> extractor
   ) {
      return new Map1To2<>(sourceKeyA, outputKeyA, outputKeyB, (actor, sourceA) -> {
         Tuple2<O1, O2> tuple = (Tuple2<O1, O2>)extractor.apply(actor, sourceA);
         return java.util.Map.of(outputKeyA, tuple.v1(), (StateKey.Sensed<O1>)outputKeyB, tuple.v2());
      });
   }

   public static <T, I1, I2, O1, O2> Map2To2<T, I1, I2, O1, O2> multiMap(
      StateKey.Sensed<I1> sourceKeyA,
      StateKey.Sensed<I2> sourceKeyB,
      StateKey.Sensed<O1> outputKeyA,
      StateKey.Sensed<O2> outputKeyB,
      Function3<? super T, ? super I1, ? super I2, ? extends Tuple2<O1, O2>> extractor
   ) {
      return new Map2To2<>(sourceKeyA, sourceKeyB, outputKeyA, outputKeyB, (actor, sourceA, sourceB) -> {
         Tuple2<O1, O2> tuple = (Tuple2<O1, O2>)extractor.apply(actor, sourceA, sourceB);
         return java.util.Map.of(outputKeyA, tuple.v1(), (StateKey.Sensed<O1>)outputKeyB, tuple.v2());
      });
   }
}
