package com.just.ai.goap.plan;

import com.just.ai.goap.Agent;
import com.just.ai.goap.action.Action;
import com.just.ai.goap.debug.AgentDiagnostics;
import com.just.ai.goap.debug.ConditionSummaries;
import com.just.ai.goap.debug.DiagnosticDetail;
import com.just.ai.goap.debug.DiagnosticDetailKeys;
import com.just.ai.goap.debug.DiagnosticEventKind;
import com.just.ai.goap.debug.DiagnosticReason;
import com.just.ai.goap.goal.Goal;
import com.just.ai.goap.state.Blackboard;
import com.just.ai.goap.state.ReadableWorldState;
import com.just.core.functional.function.Lazy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

public class Plan<T> {
   private static final AtomicLong NEXT_ID = new AtomicLong();
   private final long id = NEXT_ID.incrementAndGet();
   private final Goal goal;
   private final List<Action<? super T>> actions;
   private final float initialCost;
   private final Blackboard actionBlackboard;
   private final Action.Context<T> actionContext;
   private final Lazy<String> actionsString;
   private final Blackboard blackboard;
   private int currentActionIndex;
   private int actionTick;
   private int tick;

   public Plan(Goal goal, List<Action<? super T>> actions, float initialCost) {
      this.goal = goal;
      this.actions = Collections.unmodifiableList(actions);
      this.initialCost = initialCost;
      this.actionBlackboard = new Blackboard();
      this.actionContext = new Action.Context<>();
      this.actionsString = Lazy.of(() -> actions.stream().map(Action::getName).collect(Collectors.joining(", ")));
      this.blackboard = new Blackboard();
      this.currentActionIndex = 0;
      this.actionTick = 0;
      this.tick = 0;
   }

   public Plan.State update(Agent<T> agent, T actor, ReadableWorldState currentState, ReadableWorldState previousState) {
      Plan.State state = this.updatePlan(agent, actor, currentState, previousState);
      this.tick++;
      return state;
   }

   public List<Action<? super T>> getActions() {
      return this.actions;
   }

   public Blackboard getActionBlackboard() {
      return this.actionBlackboard;
   }

   public int getActionTick() {
      return this.actionTick;
   }

   public Blackboard getBlackboard() {
      return this.blackboard;
   }

   public long getId() {
      return this.id;
   }

   public int getCurrentActionIndex() {
      return this.currentActionIndex;
   }

   public Goal getGoal() {
      return this.goal;
   }

   public float getInitialCost() {
      return this.initialCost;
   }

   public Plan.State getPlanState() {
      return this.currentActionIndex >= this.actions.size() ? Plan.State.FINISHED : Plan.State.IN_PROGRESS;
   }

   public float getRemainingCost(T actor, ReadableWorldState worldState) {
      float remainingCost = 0.0F;

      for (int i = this.currentActionIndex; i < this.actions.size(); i++) {
         Action<? super T> action = this.actions.get(i);
         remainingCost += action.getCost(actor, worldState);
      }

      return remainingCost;
   }

   public int getTick() {
      return this.tick;
   }

   private Plan.State updatePlan(Agent<T> agent, T actor, ReadableWorldState currentState, ReadableWorldState previousState) {
      AgentDiagnostics diagnostics = agent.getDebug().getDiagnostics();
      boolean diagnosticsEnabled = diagnostics.isEnabled();
      if (this.getPlanState() == Plan.State.FINISHED) {
         return Plan.State.FINISHED;
      } else {
         Action<T> currentAction = (Action<T>)this.actions.get(this.currentActionIndex);
         this.actionContext.set(currentAction, actor, agent, this.actionBlackboard, this, currentState, previousState, diagnosticsEnabled);
         if (currentState.satisfies(currentAction.getEffectContainer())) {
            if (diagnosticsEnabled) {
               diagnostics.recordActionEvent(
                  agent.getTick(),
                  DiagnosticEventKind.ACTION_SKIPPED,
                  this,
                  this.currentActionIndex,
                  currentAction.getName(),
                  AgentDiagnostics.details(DiagnosticDetailKeys.REASON.detail(DiagnosticReason.EFFECTS_ALREADY_SATISFIED))
               );
            }

            currentAction.onFinish(this.actionContext);
            this.proceedToNextAction();
            Plan.State planState = this.getPlanState();
            if (planState == Plan.State.FINISHED) {
               return planState;
            }

            currentAction = (Action<T>)this.actions.get(this.currentActionIndex);
            this.actionContext.set(currentAction, actor, agent, this.actionBlackboard, this, currentState, previousState, diagnosticsEnabled);
         }

         if (!currentAction.getRuntimePreconditionContainer().satisfiedBy(currentState)) {
            if (diagnosticsEnabled) {
               List<String> missingRuntimeConditions = AgentDiagnostics.conditionSummaries(
                  currentAction.getRuntimePreconditionContainer().filterUnsatisfied(currentState)
               );
               diagnostics.recordActionEvent(
                  agent.getTick(),
                  DiagnosticEventKind.ACTION_INVALID,
                  this,
                  this.currentActionIndex,
                  currentAction.getName(),
                  AgentDiagnostics.details(
                     DiagnosticDetailKeys.REASON.detail(DiagnosticReason.RUNTIME_PRECONDITIONS_UNSATISFIED),
                     DiagnosticDetailKeys.MISSING_RUNTIME_CONDITIONS.detail(new ConditionSummaries(missingRuntimeConditions))
                  )
               );
            }

            currentAction.onFinish(this.actionContext);
            return Plan.State.INVALID;
         } else {
            Agent.Debugger timings = agent.getDebug().getTimings();
            // 0.4.1: these labels were concatenated for every running plan on every tick even with timings off.
            boolean timed = timings.isEnabled();
            if (this.actionTick == 0) {
               if (timed) {
                  timings.push("Action '" + currentAction.getName() + "' onStart()");
               }

               currentAction.onStart(this.actionContext);
               if (timed) {
                  timings.pop();
               }

               if (diagnosticsEnabled) {
                  diagnostics.recordActionEvent(
                     agent.getTick(),
                     DiagnosticEventKind.ACTION_STARTED,
                     this,
                     this.currentActionIndex,
                     currentAction.getName(),
                     this.actionContext.getDebugDetails()
                  );
               }
            }

            if (timed) {
               timings.push("Action '" + currentAction.getName() + "' perform()");
            }

            Action.Signal signal = currentAction.perform(this.actionContext);
            if (timed) {
               timings.pop();
            }
            if (diagnosticsEnabled) {
               ArrayList<DiagnosticDetail<?>> details = new ArrayList<>();
               details.add(DiagnosticDetailKeys.SIGNAL.detail(signal));
               details.addAll(this.actionContext.getDebugDetails());
               diagnostics.recordActionEvent(
                  agent.getTick(), DiagnosticEventKind.ACTION_PERFORMED, this, this.currentActionIndex, currentAction.getName(), details
               );
            }

            this.actionTick++;

            return switch (signal) {
               case ABORT -> Plan.State.ABORTED;
               case CONTINUE -> Plan.State.IN_PROGRESS;
            };
         }
      }
   }

   private void proceedToNextAction() {
      this.currentActionIndex = Math.clamp((long)(this.currentActionIndex + 1), 0, this.actions.size());
      this.actionTick = 0;
      this.actionBlackboard.clear();
   }

   @Override
   public String toString() {
      return "Plan{id="
         + this.id
         + ", tick="
         + this.tick
         + ", cost="
         + this.initialCost
         + ", currentActionIndex="
         + this.currentActionIndex
         + ", actionTick="
         + this.actionTick
         + ", actionBlackboard="
         + this.actionBlackboard
         + ", blackboard="
         + this.blackboard
         + ", actions=["
         + (String)this.actionsString.get()
         + "], goal="
         + this.goal
         + "}";
   }

   public static enum State {
      ABORTED,
      FINISHED,
      IN_PROGRESS,
      INVALID;
   }
}
