package com.just.ai.goap.plan.scorer;

import com.just.ai.goap.plan.Plan;
import com.just.ai.goap.state.ReadableWorldState;
import java.util.List;

@FunctionalInterface
public interface PlanScorer<T> {
   float score(Plan<T> var1, T var2, ReadableWorldState var3, List<Plan<T>> var4);
}
