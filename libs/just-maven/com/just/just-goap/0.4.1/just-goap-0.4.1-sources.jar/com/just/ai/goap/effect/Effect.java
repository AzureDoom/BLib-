package com.just.ai.goap.effect;

import com.just.ai.goap.StateKey;
import com.just.ai.goap.state.WorldState;
import java.util.function.UnaryOperator;

public sealed interface Effect<T> permits Effect.Value, Effect.Dynamic {
   StateKey.Derived<T> key();

   void apply(WorldState var1);

   public record Dynamic<T>(StateKey.Derived<T> key, UnaryOperator<T> consumer) implements Effect<T> {
      @Override
      public void apply(WorldState worldState) {
         T existingValue = worldState.getOrNull(this.key);
         if (existingValue != null) {
            T updatedValue = this.consumer.apply(existingValue);
            worldState.set(this.key, updatedValue);
         }
      }
   }

   public record Value<T>(StateKey.Derived<T> key, T value) implements Effect<T> {
      @Override
      public void apply(WorldState worldState) {
         worldState.set(this.key, this.value);
      }
   }
}
