package com.just.ai.goap.plan;

import com.just.ai.goap.Agent;
import com.just.ai.goap.graph.Graph;
import com.just.ai.goap.state.ReadableWorldState;

@FunctionalInterface
public interface ReplanPolicy<T> {
   boolean shouldReplan(ReplanPolicy.Context<T> var1);

   default ReplanDecision evaluate(ReplanPolicy.Context<T> context) {
      return this.shouldReplan(context) ? ReplanDecision.triggered(ReplanReason.CUSTOM_POLICY) : ReplanDecision.skipped(ReplanReason.CUSTOM_POLICY);
   }

   public record Context<T>(Agent<T> agent, Graph<T> graph, ReadableWorldState worldState, ReadableWorldState previousWorldState) {
   }
}
