package com.just.ai.goap.plan;

import com.just.ai.goap.AOStar;
import com.just.ai.goap.Agent;
import com.just.ai.goap.action.Action;
import com.just.ai.goap.condition.ConditionContainer;
import com.just.ai.goap.debug.AgentDiagnostics;
import com.just.ai.goap.debug.PlanSearchBuilder;
import com.just.ai.goap.debug.PlanSearchStatus;
import com.just.ai.goap.goal.Goal;
import com.just.ai.goap.graph.Graph;
import com.just.ai.goap.state.ReadableWorldState;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class DefaultPlanFactory {
   public static <T> List<Plan<T>> create(Graph<T> graph, T actor, ReadableWorldState worldState, Agent.Debug debug) {
      ArrayList<Plan<T>> plans = new ArrayList<>();
      Agent.Debugger timings = debug.getTimings();
      AgentDiagnostics diagnostics = debug.getDiagnostics();
      boolean diagnosticsEnabled = diagnostics.isEnabled();
      // 0.4.1: the timing labels below were concatenated for every goal on every replan even with timings off.
      boolean timed = timings.isEnabled();

      for (Goal goal : graph.getAvailableGoals()) {
         PlanSearchBuilder searchBuilder = diagnosticsEnabled ? new PlanSearchBuilder(timings.getAgentTick(), goal) : null;
         if (timed) {
            timings.push("Goal '" + goal.getName() + "' precondition check");
         }

         boolean preconditionsSatisfied = goal.getPreconditions().satisfiedBy(worldState);
         if (timed) {
            timings.pop();
         }
         if (searchBuilder != null) {
            searchBuilder.setGoalPreconditionsSatisfied(preconditionsSatisfied);
            searchBuilder.setDesiredConditionsSatisfied(goal.getDesiredConditions().satisfiedBy(worldState));
         }

         if (preconditionsSatisfied) {
            ConditionContainer desiredConditions = goal.getDesiredConditions();
            if (timed) {
               timings.push("AOStar.solve() for goal '" + goal.getName() + "'");
            }

            List<AOStar.ActionWithCost<? super T>> actionsWithCosts = AOStar.solve(graph, desiredConditions, worldState, actor, searchBuilder);
            if (timed) {
               timings.pop();
            }
            if (actionsWithCosts != null && !actionsWithCosts.isEmpty()) {
               float cost = 0.0F;
               ArrayList<Action<? super T>> actions = new ArrayList<>(actionsWithCosts.size());

               for (AOStar.ActionWithCost<? super T> actionWithCost : actionsWithCosts) {
                  cost += actionWithCost.cost();
                  actions.add(actionWithCost.action());
               }

               plans.add(new Plan<>(goal, actions, cost));
            } else if (actionsWithCosts != null && searchBuilder != null) {
               searchBuilder.setStatus(PlanSearchStatus.ALREADY_SATISFIED);
            }

            if (searchBuilder != null) {
               diagnostics.recordPlanSearch(searchBuilder.build());
            }
         } else if (searchBuilder != null) {
            searchBuilder.setStatus(PlanSearchStatus.GOAL_BLOCKED);
            diagnostics.recordPlanSearch(searchBuilder.build());
         }
      }

      plans.sort(Comparator.comparingDouble(Plan::getInitialCost));
      return plans;
   }

   private DefaultPlanFactory() {
      throw new UnsupportedOperationException();
   }
}
