package com.just.ai.goap.debug;

import com.just.ai.goap.AOStar;
import com.just.ai.goap.action.Action;
import com.just.ai.goap.condition.Condition;
import com.just.ai.goap.condition.ConditionContainer;
import com.just.ai.goap.goal.Goal;
import java.util.ArrayList;
import java.util.List;

public final class PlanSearchBuilder implements PlanSearchCollector {
   private static final int MAX_SEARCH_STEPS = 512;
   private final long tick;
   private final String goalName;
   private boolean goalPreconditionsSatisfied;
   private boolean desiredConditionsSatisfied;
   private List<String> rootUnsatisfiedConditions;
   private final List<PlanSearchBuilder.MutablePlanSearchStep> steps;
   private PlanSearchStatus status;
   private List<String> selectedActions;
   private float cost;
   private boolean truncated;
   private PlanSearchBuilder.MutablePlanSearchStep currentStep;

   public PlanSearchBuilder(long tick, Goal goal) {
      this.tick = tick;
      this.goalName = goal.getName();
      this.goalPreconditionsSatisfied = false;
      this.desiredConditionsSatisfied = false;
      this.rootUnsatisfiedConditions = List.of();
      this.steps = new ArrayList<>();
      this.status = PlanSearchStatus.NO_PLAN;
      this.selectedActions = List.of();
      this.cost = 0.0F;
      this.truncated = false;
      this.currentStep = null;
   }

   public void setGoalPreconditionsSatisfied(boolean goalPreconditionsSatisfied) {
      this.goalPreconditionsSatisfied = goalPreconditionsSatisfied;
   }

   public void setDesiredConditionsSatisfied(boolean desiredConditionsSatisfied) {
      this.desiredConditionsSatisfied = desiredConditionsSatisfied;
   }

   public void setStatus(PlanSearchStatus status) {
      this.status = status;
   }

   @Override
   public void started(ConditionContainer rootUnsatisfied) {
      this.rootUnsatisfiedConditions = AgentDiagnostics.conditionSummaries(rootUnsatisfied);
   }

   @Override
   public void expanded(Condition<?> condition, List<? extends Action<?>> candidateActions) {
      if (this.steps.size() >= 512) {
         this.truncated = true;
         this.currentStep = null;
      } else {
         PlanSearchBuilder.MutablePlanSearchStep step = new PlanSearchBuilder.MutablePlanSearchStep(
            condition.toString(), AgentDiagnostics.actionNames(candidateActions)
         );
         this.steps.add(step);
         this.currentStep = step;
      }
   }

   @Override
   public void triedAction(Action<?> action, ConditionContainer newUnsatisfied, float actionCost, float heuristicCost) {
      if (this.currentStep != null) {
         this.currentStep
            .attempts
            .add(new PlanSearchActionAttempt(action.getName(), AgentDiagnostics.conditionSummaries(newUnsatisfied), actionCost, heuristicCost));
      }
   }

   @Override
   public void solved(List<? extends AOStar.ActionWithCost<?>> plan) {
      ArrayList<String> actions = new ArrayList<>(plan.size());
      float totalCost = 0.0F;

      for (AOStar.ActionWithCost<?> actionWithCost : plan) {
         actions.add(actionWithCost.action().getName());
         totalCost += actionWithCost.cost();
      }

      this.status = actions.isEmpty() ? PlanSearchStatus.ALREADY_SATISFIED : PlanSearchStatus.SOLVED;
      this.selectedActions = actions;
      this.cost = totalCost;
   }

   @Override
   public void failed() {
      this.status = PlanSearchStatus.NO_PLAN;
   }

   public PlanSearchResult build() {
      ArrayList<PlanSearchStep> immutableSteps = new ArrayList<>(this.steps.size());

      for (PlanSearchBuilder.MutablePlanSearchStep step : this.steps) {
         immutableSteps.add(step.toImmutable());
      }

      return new PlanSearchResult(
         this.tick,
         this.goalName,
         this.goalPreconditionsSatisfied,
         this.desiredConditionsSatisfied,
         this.rootUnsatisfiedConditions,
         this.status,
         this.selectedActions,
         this.cost,
         this.truncated,
         immutableSteps
      );
   }

   private static final class MutablePlanSearchStep {
      private final String condition;
      private final List<String> candidateActions;
      private final List<PlanSearchActionAttempt> attempts;

      private MutablePlanSearchStep(String condition, List<String> candidateActions) {
         this.condition = condition;
         this.candidateActions = candidateActions;
         this.attempts = new ArrayList<>();
      }

      private PlanSearchStep toImmutable() {
         return new PlanSearchStep(this.condition, this.candidateActions, this.attempts);
      }
   }
}
