package com.just.ai.goap;

import com.just.ai.goap.debug.AgentDiagnostics;
import com.just.ai.goap.graph.Graph;
import com.just.ai.goap.plan.DefaultPlanFactory;
import com.just.ai.goap.plan.Plan;
import com.just.ai.goap.plan.ReplanDecision;
import com.just.ai.goap.plan.ReplanPolicies;
import com.just.ai.goap.plan.ReplanPolicy;
import com.just.ai.goap.plan.executor.PlanExecutor;
import com.just.ai.goap.plan.executor.impl.BestPlanExecutor;
import com.just.ai.goap.plan.scorer.PlanScorers;
import com.just.ai.goap.state.Blackboard;
import com.just.ai.goap.state.ReadableWorldState;
import com.just.ai.goap.state.SensingWorldState;
import com.just.ai.goap.state.WorldState;
import java.util.ArrayDeque;
import java.util.List;
import java.util.function.UnaryOperator;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Agent<T> {
   private final T actor;
   private final Blackboard blackboard;
   private final Agent.Debug debug;
   private final Blackboard graphBlackboard;
   private final PlanExecutor<T> planExecutor;
   private final Agent.PlanFactory<T> planFactory;
   private final ReplanPolicy<T> replanPolicy;
   private final WorldState previousWorldState;
   @Nullable
   private SensingWorldState<T> currentWorldState;
   private long tick;
   /** 0.4.1: see {@link #setSensingOptimizationsEnabled}. */
   private boolean sensingOptimizationsEnabled = true;

   public static <T> Agent<T> create(T actor) {
      return builder(actor).build();
   }

   public static <T> Agent.Builder<T> builder(T actor) {
      return new Agent.Builder<>(actor);
   }

   private Agent(T actor, PlanExecutor<T> planExecutor, Agent.PlanFactory<T> planFactory, ReplanPolicy<T> replanPolicy) {
      this.actor = actor;
      this.blackboard = new Blackboard();
      this.debug = new Agent.Debug(new Agent.Debugger(this), new AgentDiagnostics());
      this.graphBlackboard = new Blackboard();
      this.planExecutor = planExecutor;
      this.planFactory = planFactory;
      this.previousWorldState = WorldState.create();
      this.replanPolicy = replanPolicy;
      this.currentWorldState = null;
      this.tick = 0L;
   }

   public void update(Graph<T> graph) {
      Agent.Debugger timings = this.debug.getTimings();
      timings.push("Agent.update()");
      this.prepareWorldStates(graph, this.actor);
      this.supplyPlansIfNeeded(graph, this.actor);
      this.executePlans(this.actor);
      this.tick++;
      timings.pop();
   }

   public void abandonPlan() {
      this.planExecutor.abandonAllPlans();
   }

   public boolean hasPlan() {
      return this.planExecutor.hasActivePlans();
   }

   public T getActor() {
      return this.actor;
   }

   public Blackboard getBlackboard() {
      return this.blackboard;
   }

   @Nullable
   public ReadableWorldState getCurrentWorldState() {
      return this.currentWorldState;
   }

   public Agent.Debug getDebug() {
      return this.debug;
   }

   public Blackboard getGraphBlackboard() {
      return this.graphBlackboard;
   }

   public PlanExecutor<T> getPlanExecutor() {
      return this.planExecutor;
   }

   public long getTick() {
      return this.tick;
   }

   public boolean isSensingOptimizationsEnabled() {
      return this.sensingOptimizationsEnabled;
   }

   /**
    * 0.4.1: switches the sensing optimisations in {@link SensingWorldState} - sensed-null memoisation and sensor
    * refresh windows ({@link com.just.ai.goap.sensor.Sensors#every}). On by default. Off restores the 0.4.0 behaviour
    * exactly: every value is discarded every tick and a {@code null} reading is re-sensed on every read. Takes effect
    * on the next {@link #update}.
    */
   public void setSensingOptimizationsEnabled(boolean sensingOptimizationsEnabled) {
      this.sensingOptimizationsEnabled = sensingOptimizationsEnabled;
   }

   private void prepareWorldStates(Graph<T> graph, T actor) {
      if (this.currentWorldState == null || this.currentWorldState.getGraph() != graph) {
         this.currentWorldState = new SensingWorldState<>(graph);
         this.graphBlackboard.clear();
      }

      this.currentWorldState.setActor(actor);
      this.currentWorldState.setOptimizationsEnabled(this.sensingOptimizationsEnabled);
      this.previousWorldState.clear();
      this.previousWorldState.setAll(this.currentWorldState.getMap());
      if (this.sensingOptimizationsEnabled) {
         // Keeps values still inside a sensor refresh window; discards everything else, as clear() did.
         this.currentWorldState.advanceTick();
      } else {
         this.currentWorldState.clear();
      }
   }

   private void supplyPlansIfNeeded(Graph<T> graph, T actor) {
      ReplanPolicy.Context<T> context = new ReplanPolicy.Context<>(this, graph, this.currentWorldState, this.previousWorldState);
      AgentDiagnostics diagnostics = this.debug.getDiagnostics();
      boolean shouldReplan = diagnostics.isEnabled() ? this.evaluateReplanPolicyWithDiagnostics(context, diagnostics) : this.replanPolicy.shouldReplan(context);
      if (shouldReplan) {
         Agent.Debugger timings = this.debug.getTimings();
         timings.push("planFactory.create()");
         List<Plan<T>> plans = this.planFactory.create(graph, actor, this.currentWorldState, this.debug);
         timings.pop();
         diagnostics.recordPlansCreated(this.tick, plans);
         timings.push("Agent.supplyPlans()");
         this.planExecutor.supplyPlans(new PlanExecutor.SupplyContext<>(this, plans, actor, this.currentWorldState));
         timings.pop();
      }
   }

   private boolean evaluateReplanPolicyWithDiagnostics(ReplanPolicy.Context<T> context, AgentDiagnostics diagnostics) {
      ReplanDecision decision = this.replanPolicy.evaluate(context);
      diagnostics.recordReplanDecision(this.tick, decision);
      return decision.shouldReplan();
   }

   private void executePlans(T actor) {
      Agent.Debugger timings = this.debug.getTimings();
      timings.push("Agent.executePlans()");
      PlanExecutor.ExecutionContext<T> context = new PlanExecutor.ExecutionContext<>(this, actor, this.currentWorldState, this.previousWorldState);
      this.planExecutor.execute(context);
      timings.pop();
   }

   public static class Builder<T> {
      private final T actor;
      private PlanExecutor<T> planExecutor;
      private Agent.PlanFactory<T> planFactory;
      private ReplanPolicy<T> replanPolicy;

      private Builder(T actor) {
         this.actor = actor;
         this.planExecutor = new BestPlanExecutor<>(PlanScorers.costEfficiency());
         this.planFactory = DefaultPlanFactory::create;
         this.replanPolicy = ReplanPolicies.ifNoActivePlans();
      }

      public Agent.Builder<T> withPlanExecutor(PlanExecutor<T> planExecutor) {
         this.planExecutor = planExecutor;
         return this;
      }

      public Agent.Builder<T> withPlanFactory(Agent.PlanFactory<T> planFactory) {
         this.planFactory = planFactory;
         return this;
      }

      public Agent.Builder<T> withReplanPolicy(ReplanPolicy<T> replanPolicy) {
         this.replanPolicy = replanPolicy;
         return this;
      }

      public Agent.Builder<T> apply(UnaryOperator<Agent.Builder<T>> unaryOperator) {
         return unaryOperator.apply(this);
      }

      public Agent<T> build() {
         return new Agent<>(this.actor, this.planExecutor, this.planFactory, this.replanPolicy);
      }
   }

   public static final class Debug {
      private final Agent.Debugger timings;
      private final AgentDiagnostics diagnostics;

      private Debug(Agent.Debugger timings, AgentDiagnostics diagnostics) {
         this.timings = timings;
         this.diagnostics = diagnostics;
      }

      public Agent.Debugger getTimings() {
         return this.timings;
      }

      public AgentDiagnostics getDiagnostics() {
         return this.diagnostics;
      }
   }

   public static final class Debugger {
      private static final Logger LOGGER = LoggerFactory.getLogger(Agent.Debugger.class);
      private final Agent<?> agent;
      private final ArrayDeque<Agent.Debugger.Frame> frameStack;
      private boolean enabled;

      public Debugger(Agent<?> agent) {
         this.agent = agent;
         this.frameStack = new ArrayDeque<>();
         this.enabled = false;
      }

      public boolean isEnabled() {
         return this.enabled;
      }

      public long getAgentTick() {
         return this.agent.getTick();
      }

      public void setEnabled(boolean enabled) {
         this.enabled = enabled;
      }

      public void push(String name) {
         if (this.isEnabled()) {
            this.frameStack.push(new Agent.Debugger.Frame(name, System.nanoTime()));
         }
      }

      public void pop() {
         if (this.isEnabled()) {
            if (!this.frameStack.isEmpty()) {
               Agent.Debugger.Frame frame = this.frameStack.pop();
               double timeMs = (System.nanoTime() - frame.startTime) / 1000000.0;
               if (this.enabled) {
                  LOGGER.debug("T={}, {} completed in {}ms", new Object[]{this.agent.getTick(), frame.name, timeMs});
               }
            }
         }
      }

      private record Frame(String name, long startTime) {
      }
   }

   public interface PlanFactory<T> {
      List<Plan<T>> create(Graph<T> var1, T var2, SensingWorldState<T> var3, Agent.Debug var4);
   }
}
