package com.just.ai.goap.condition.expression;

import java.util.function.Predicate;
import org.jetbrains.annotations.NotNull;

public final class Expression<T> {
   private final String description;
   private final Predicate<? super T> predicate;

   Expression(String description, Predicate<? super T> predicate) {
      this.description = description;
      this.predicate = predicate;
   }

   public boolean evaluate(@NotNull T actual) {
      return this.predicate.test(actual);
   }

   @NotNull
   @Override
   public String toString() {
      return this.description;
   }

   public <U extends T> Expression<U> and(Expression<? super U> other) {
      return new Expression<>(this.description + " && " + other.description, value -> this.evaluate((T)value) && other.evaluate(value));
   }

   public <U extends T> Expression<U> or(Expression<? super U> other) {
      return new Expression<>(this.description + " || " + other.description, value -> this.evaluate((T)value) || other.evaluate(value));
   }

   public Expression<T> negate(String newDescription) {
      return new Expression<>(newDescription, Predicate.not(this::evaluate));
   }
}
